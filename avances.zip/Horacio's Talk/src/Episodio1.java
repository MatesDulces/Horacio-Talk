import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.net.URL;

public class Episodio1 extends JFrame implements KeyListener {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JLabel lblNewLabel_1;
    private Timer textTimer;
    private DialogManager dialogManager;
    private boolean mostrandoTexto = false;
    private boolean animacionCompletada = false;
    private JLabel panchoLabel; 
    private boolean tienePan = false;
    private boolean tieneSalchicha = false;
    private boolean tieneMayonesa = false;
    private boolean tieneKetchup = false;
    private boolean tieneMostaza = false;
    private JButton btnEntregarPedido; 
    
    private ImageIcon escalarImagen(String ruta, int ancho, int alto) {
        URL imgUrl = Episodio1.class.getResource(ruta);
        ImageIcon imagenOriginal = new ImageIcon(imgUrl);
        Image imagen = imagenOriginal.getImage();
        Image imagenEscalada = imagen.getScaledInstance(ancho, alto, Image.SCALE_SMOOTH);
        return new ImageIcon(imagenEscalada);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Episodio1 frame = new Episodio1();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Episodio1() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true);
        addKeyListener(this);
        setFocusable(true);

        dialogManager = new DialogManager();

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.window);
        contentPane.setBorder(null);
        setContentPane(contentPane);
        contentPane.setPreferredSize(screenSize);
        contentPane.setSize(screenSize);
        contentPane.setLayout(null);

        contentPane.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (!animacionCompletada) return;

                if (mostrandoTexto) {
                    textTimer.stop();
                    lblNewLabel_1.setText("<html>" + dialogManager.getDialogoActual().replaceAll("\n", "<br>") + "</html>");
                    mostrandoTexto = false;
                } else {
                    if (dialogManager.hayMasDialogos()) {
                        dialogManager.siguienteDialogo();
                        iniciarAnimacionTexto();
                    }
                }
            }
        });

        JLabel lblNewLabel = new JLabel("");
        lblNewLabel.setBounds(1050, -100, 1451, 900);
        lblNewLabel.setIcon(escalarImagen("/imagenes/lachinacreoquefunciona.png", 1500, 1000));
        contentPane.add(lblNewLabel);

        JLabel backgroundLabel = new JLabel("");
        backgroundLabel.setBounds(0, 0, screenSize.width, screenSize.height);
        backgroundLabel.setIcon(escalarImagen("/imagenes/Carrito1.png", screenSize.width, screenSize.height));
        contentPane.add(backgroundLabel);

        lblNewLabel_1 = new JLabel("");
        lblNewLabel_1.setBackground(SystemColor.text);
        lblNewLabel_1.setVerticalAlignment(SwingConstants.TOP);
        lblNewLabel_1.setForeground(SystemColor.textHighlight);
        lblNewLabel_1.setBounds(100, 30, 1950, 200);
        lblNewLabel_1.setFont(new Font("Cascadia Code", Font.BOLD, 40));
        contentPane.add(lblNewLabel_1);

        contentPane.setComponentZOrder(lblNewLabel, contentPane.getComponentCount() - 1);
        contentPane.setComponentZOrder(backgroundLabel, contentPane.getComponentCount() - 2);

        panchoLabel = new JLabel(escalarImagen("/imagenes/pancho_vacio.png", 400, 200));
        contentPane.add(panchoLabel);

        setSize(800, 600);

        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                int windowWidth = getContentPane().getWidth();
                int windowHeight = getContentPane().getHeight();
                
                panchoLabel.setBounds(
                    (windowWidth - 400) / 2,
                    (windowHeight - (-200)) / 2,
                    400, 
                    200
                );
            }
        });

        contentPane.setComponentZOrder(panchoLabel, 0);

        crearBotonesIngredientes();
        crearBotonEntregarPedido(); 

        int startX = 1000;
        int finalX = (screenSize.width - 1500) / 2;
        int y = -150;

        Timer timer = new Timer(16, new ActionListener() {
            int currentX = startX;
            boolean animacionEntradaCompletada = false;

            public void actionPerformed(ActionEvent e) {
                int step = 8;
                
                if (!animacionEntradaCompletada) {
                    currentX -= step;  
                    if (currentX <= finalX) {
                        currentX = finalX;
                        animacionEntradaCompletada = true;
                        animacionCompletada = true;
                        iniciarAnimacionTexto();
                    }
                }
                else if (dialogManager.getDialogoActual().equals("HORACIO: (Ojal� que vuelva tambi�n, es una persona agradable).") && animacionEntradaCompletada) {
                    currentX -= step;  
                    if (currentX <= -1500) {  
                        ((Timer) e.getSource()).stop();
                        Episodio1_Acto2 episodio1_acto2 = new Episodio1_Acto2(); 
                        episodio1_acto2.setVisible(true);
                        dispose(); 

                    }
                }
                lblNewLabel.setBounds(currentX, y, 1500, 1000);
                contentPane.revalidate();
                contentPane.repaint();
            }
        });

        setSize(screenSize);
        setLocationRelativeTo(null);
        setResizable(false);

        timer.start();
    }
    private void iniciarAnimacionTexto() {
        if (textTimer != null && textTimer.isRunning()) {
            textTimer.stop();
        }

        String textoCompleto = dialogManager.getDialogoActual();
        mostrandoTexto = true;

        textTimer = new Timer(50, new ActionListener() {
            int index = 0;
            StringBuilder textoActual = new StringBuilder();

            @Override
            public void actionPerformed(ActionEvent e) {
                if (index < textoCompleto.length()) {
                    textoActual.append(textoCompleto.charAt(index));
                    lblNewLabel_1.setText("<html>" + textoActual.toString().replaceAll("\n", "<br>") + "</html>");
                    index++;
                } else {
                    ((Timer) e.getSource()).stop();
                    mostrandoTexto = false;
                }
            }
        });

        textTimer.start();
    }

    private void crearBotonesIngredientes() {
        String[] ingredientes = {"Pan", "Salchicha", "Mayonesa", "Ketchup", "Mostaza"};

        int tamanoBoton = (int)(getContentPane().getWidth() * 0.07);

        int margenX = (int)(getContentPane().getWidth() * 0.10);

        int posicionY = (int)(getContentPane().getHeight() * 0.85);

        for (int i = 0; i < ingredientes.length; i++) {
            String ingrediente = ingredientes[i];
            JButton boton;

            String rutaImagen = "/ingredientes/" + ingrediente.toUpperCase() + ".png";
            ImageIcon icono = escalarImagen(rutaImagen, tamanoBoton, tamanoBoton);
            boton = new JButton(icono);

            boton.setBorderPainted(false);
            boton.setContentAreaFilled(false);
            boton.setFocusPainted(false);

            boton.addActionListener(e -> agregarIngrediente(ingrediente));

            int posicionX = margenX + (tamanoBoton + margenX) * i;
            boton.setBounds(posicionX, posicionY, tamanoBoton, tamanoBoton);

            contentPane.add(boton);
            contentPane.setComponentZOrder(boton, 0); 

        }

        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                int nuevoTamanoBoton = (int)(getContentPane().getWidth() * 0.10);
                int nuevoMargenX = (int)(getContentPane().getWidth() * 0.07);
                int nuevaPosicionY = (int)(getContentPane().getHeight() * 0.85);

                Component[] components = contentPane.getComponents();
                int i = 0;
                for (Component comp : components) {
                    if (comp instanceof JButton) {
                        int nuevoPosicionX = nuevoMargenX + (nuevoTamanoBoton + nuevoMargenX) * i;
                        comp.setBounds(nuevoPosicionX, nuevaPosicionY, nuevoTamanoBoton, nuevoTamanoBoton);
                        i++;
                    }
                }
            }
        });
    }
    private void agregarIngrediente(String ingrediente) {
        switch (ingrediente) {
            case "Pan":
                tienePan = !tienePan;
                break;
            case "Salchicha":
                tieneSalchicha = !tieneSalchicha;
                break;
            case "Mayonesa":
                tieneMayonesa = !tieneMayonesa;
                break;
            case "Ketchup":
                tieneKetchup = !tieneKetchup;
                break;
            case "Mostaza":
                tieneMostaza = !tieneMostaza;
                break;
        }
        actualizarImagenPancho();
    }

    private void actualizarImagenPancho() {
        String imagenRuta = "/imagenes/pancho_vacio.png";

        if (tienePan) {
            imagenRuta = "/imagenes/Pan.png";
        }
        if (tienePan && tieneSalchicha) {
            imagenRuta = "/imagenes/Pancho_Simple.png";
        }
        if (tienePan && tieneSalchicha && tieneMayonesa) {
            imagenRuta = "/imagenes/Pancho_Con_Mayo.png";
        }
        if (tienePan && tieneSalchicha && tieneKetchup) {
            imagenRuta = "/imagenes/Pancho_Con_Ketchup.png";
        }
        if (tienePan && tieneSalchicha && tieneMostaza) {
            imagenRuta = "/imagenes/Pancho_Con_Mostaza.png";
        }
        if (tienePan && tieneSalchicha && tieneMayonesa && tieneKetchup) {
            imagenRuta = "/imagenes/Pancho_Con_MayoYKetchup.png";
        }
        if (tienePan && tieneSalchicha && tieneMayonesa && tieneMostaza) {
            imagenRuta = "/imagenes/Pancho_Con_MayoYMostaza.png";
        }
        if (tienePan && tieneSalchicha && tieneMostaza && tieneKetchup) {
            imagenRuta = "/imagenes/Pancho_Con_MostazaYKetchup.png";
        }
        if (tienePan && tieneSalchicha && tieneMostaza && tieneKetchup && tieneMayonesa) {
            imagenRuta = "/imagenes/Pancho_Con_Todo.png";
        }

        panchoLabel.setIcon(escalarImagen(imagenRuta, 1600, 800));
    }

    private void crearBotonEntregarPedido() {
        btnEntregarPedido = new JButton();
        
        btnEntregarPedido.setBounds(100, 350, 200, 50);
        
        btnEntregarPedido.setBorder(null);
        
        btnEntregarPedido.setContentAreaFilled(false);
        btnEntregarPedido.setOpaque(false);
        
        ImageIcon iconoEntregar = new ImageIcon(Episodio1.class.getResource("/ingredientes/entregar.png"));
        
        Image imgEscalada = iconoEntregar.getImage().getScaledInstance(200, 50, Image.SCALE_SMOOTH);
        
        btnEntregarPedido.setIcon(new ImageIcon(imgEscalada));
        
        btnEntregarPedido.setIconTextGap(0); 
        
        btnEntregarPedido.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                entregarPedido();
            }
        });
        
        contentPane.add(btnEntregarPedido);
        contentPane.setComponentZOrder(btnEntregarPedido, 0); 

        JLabel lblNewLabel_2 = new JLabel("New label");
        lblNewLabel_2.setIcon(new ImageIcon(Episodio1.class.getResource("/imagenes/fondoplaya.png")));
        lblNewLabel_2.setBounds(0, 0, 1920, 1080);
        contentPane.add(lblNewLabel_2);
    }


    private void entregarPedido() {
        final boolean pedidoCorrecto = tienePan && tieneKetchup && tieneSalchicha && !tieneMayonesa && !tieneMostaza;

        String dialogoPedido = dialogManager.obtenerDialogoPedido(pedidoCorrecto);

        lblNewLabel_1.setText("<html>" + dialogoPedido.replaceAll("\n", "<br>") + "</html>");

        Timer timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (pedidoCorrecto) {
                    dialogManager.reanudarDialogos(pedidoCorrecto); // Reanudar di�logos
                    panchoLabel.setVisible(false);
                    if (dialogManager.siguienteDialogo()) {
                        iniciarAnimacionTexto();
                    }
                } else {
                }
            }
        });
        timer.setRepeats(false);
        timer.start();
    }





    @Override
    public void keyPressed(KeyEvent e) {}
    @Override
    public void keyReleased(KeyEvent e) {}
    @Override
    public void keyTyped(KeyEvent e) {}
}
