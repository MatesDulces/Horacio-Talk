
public class Episodio3 {

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}

}
