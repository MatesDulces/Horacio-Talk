import java.util.ArrayList;
import java.util.List;

public class DialogManager1_Acto2 {
    private String[] dialogos;
    private int dialogoActual;
    private String[][] pedidos;
    private int indiceClienteActual = 0;
    private boolean debeAnimar = false;
    private List<String> pedidoEnProceso; // Nueva variable para tracking del pedido actual
    private boolean enPausa = false;
    // Agregar una variable para controlar si es momento de la animación de salida

    public DialogManager1_Acto2() {
        // Agregar los diálogos básicos
        dialogos = new String[]{
            "HORACIO: Ah, mi primer cliente",
            "*Horacio se prepara para atender a la joven que llega*",
            "CLIENTA: Hola buen dia, �te puedo pedir un pancho con ketchup?",
            "CLIENTA: Para preparar el pedido, selecciona los ingredientes en orden \ndesde el menu izquierdo.",
            "HORACIO: Como no, ya va",
            // Los diálogos relacionados con el pedido solo serán actualizados al presionar el botón
            "CLIENTA: Gracias muy amable",
            "CLIENTA: Hola buen dia, te puedo pedir un pancho con ketchup y mayo?",
            "CLIENTA: Para preparar el pedido, selecciona los ingredientes en orden \ndesde el menu izquierdo.",
            "HORACIO: Como no, ya va",
            "CLIENTA: chau",
            "CLIENTA: Gracias muy amable..."
        };
      
            pedidos = new String[][]{
                {"Pan", "Salchicha", "Ketchup"},
                {"Pan", "Salchicha", "Ketchup", "Mayonesa"}
            };
            
            pedidoEnProceso = new ArrayList<>();
            dialogoActual = 0;
        }

        // Método para agregar ingrediente al pedido actual
        public void agregarIngrediente(String ingrediente) {
            pedidoEnProceso.add(ingrediente);
        }

        // Método para limpiar el pedido en proceso
        public void limpiarPedidoEnProceso() {
            pedidoEnProceso.clear();
        }

        public String[] getPedidoEsperado() {
            if (indiceClienteActual < pedidos.length) {
                return pedidos[indiceClienteActual];
            }
            return new String[0];
        }

        public List<String> getPedidoEnProceso() {
            return pedidoEnProceso;
        }

        public boolean siguienteDialogo() {
            if (enPausa) {
                return false;
            }

            if (dialogoActual < dialogos.length - 1) {
                dialogoActual++;
                
                // Pausa el diálogo cuando llegamos al momento de preparar el pedido
                if (dialogoActual == 4) {
                    enPausa = true;
                }

                if (dialogos[dialogoActual].contains("Gracias muy amable")) {
                    debeAnimar = true;
                }

                return true;
            }

            return false;
        }

        public void reanudarDialogos(boolean pedidoCorrecto) {
            if (pedidoCorrecto) {
                enPausa = false;
                limpiarPedidoEnProceso();
            }
        }

        public void avanzarCliente() {
            if (indiceClienteActual < pedidos.length - 1) {
                indiceClienteActual++;
                limpiarPedidoEnProceso();
            }
        }
   

    public String[] getPedidoActual() {
        if (indiceClienteActual < pedidos.length) {
            return pedidos[indiceClienteActual];  // Utiliza indiceClienteActual para devolver el pedido correcto
        }
        return null;  // Si no hay más pedidos, devuelve null
    }



    public String getDialogoActual() {
        if (dialogoActual < dialogos.length) {
            return dialogos[dialogoActual];
        }
        return "";
    }

 

    // Agregar método para verificar si debe animar
    public boolean debeAnimar() {
        return debeAnimar;
    }

    // Agregar método para resetear la animación
    public void resetearAnimacion() {
        debeAnimar = false;
    }

    // ... (mantener el resto de los métodos igual)

    

    public boolean hayMasDialogos() {
        return dialogoActual < dialogos.length - 1;
    }

    public void reiniciarDialogos() {
        dialogoActual = 0;
        debeAnimar = false;
    }

  
    }
 
