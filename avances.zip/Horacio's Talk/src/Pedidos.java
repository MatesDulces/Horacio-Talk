// Clase para representar un pedido
class Pedidos {
    boolean tienePan;
    boolean tieneKetchup;
    boolean tieneSalchicha;
    boolean tieneMayonesa;
    boolean tieneMostaza;

    public Pedidos(boolean pan, boolean ketchup, boolean salchicha, boolean mayonesa, boolean mostaza) {
        this.tienePan = pan;
        this.tieneKetchup = ketchup;
        this.tieneSalchicha = salchicha;
        this.tieneMayonesa = mayonesa;
        this.tieneMostaza = mostaza;
    }

    // Método para verificar si el pedido es correcto
    public boolean esCorrecto(boolean pan, boolean ketchup, boolean salchicha, boolean mayonesa, boolean mostaza) {
        return this.tienePan == pan &&
               this.tieneKetchup == ketchup &&
               this.tieneSalchicha == salchicha &&
               this.tieneMayonesa == mayonesa &&
               this.tieneMostaza == mostaza;
    }
}
