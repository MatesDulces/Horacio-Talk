import java.awt.*;
import java.awt.event.*;
import java.util.List;
import javax.swing.JOptionPane;
import java.util.Arrays;
import javax.swing.*;
import java.net.URL;

public class Episodio1_Acto2 extends JFrame implements KeyListener {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JLabel lblNewLabel_1;
    private Timer textTimer;
    private DialogManager1_Acto2 dialogmanager1_Acto2;
    private boolean mostrandoTexto = false;
    private boolean animacionCompletada = false;
    private JLabel panchoLabel; // JLabel para mostrar el pancho
    private boolean tienePan = false;
    private boolean tieneSalchicha = false;
    private boolean tieneMayonesa = false;
    private boolean tieneKetchup = false;
    private boolean tieneMostaza = false;
    private JButton btnEntregarPedido; // Bot�n para entregar el pedido
    private JLabel lblNewLabel_2;
    private JLabel lblNewLabel; // Para NPC1
    private JLabel lblNewLabel2; // Para Thiago
    private boolean primerPersonajeTermino = false;
    
    private ImageIcon escalarImagen(String ruta, int ancho, int alto) {
        URL imgUrl = Episodio1_Acto2.class.getResource(ruta);
        if (imgUrl == null) {
            System.err.println("Error: La imagen no se pudo encontrar en la ruta: " + ruta);
            return null; // o puedes retornar una imagen por defecto aqu�
        }
        ImageIcon imagenOriginal = new ImageIcon(imgUrl);
        Image imagen = imagenOriginal.getImage();
        Image imagenEscalada = imagen.getScaledInstance(ancho, alto, Image.SCALE_SMOOTH);
        return new ImageIcon(imagenEscalada);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Episodio1_Acto2 frame = new Episodio1_Acto2();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Episodio1_Acto2() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true);
        addKeyListener(this);
        setFocusable(true);

        dialogmanager1_Acto2 = new DialogManager1_Acto2();

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.window);
        contentPane.setBorder(null);
        setContentPane(contentPane);
        contentPane.setPreferredSize(screenSize);
        contentPane.setSize(screenSize);
        contentPane.setLayout(null);

        contentPane.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (!animacionCompletada) return;

                if (mostrandoTexto) {
                    textTimer.stop();
                    lblNewLabel_1.setText("<html>" + dialogmanager1_Acto2 .getDialogoActual().replaceAll("\n", "<br>") + "</html>");
                    mostrandoTexto = false;
                } else {
                    if (dialogmanager1_Acto2 .hayMasDialogos()) {
                    	dialogmanager1_Acto2 .siguienteDialogo();
                        iniciarAnimacionTexto();
                    }
                }
            }
        });
     // Labels de personajes (al fondo)
        lblNewLabel2 = new JLabel("");
        lblNewLabel2.setBounds(1050, -100, 1451, 900);
        lblNewLabel2.setIcon(escalarImagen("/imagenes/Thiago.png", 1500, 1000));
        lblNewLabel2.setVisible(false);
        contentPane.add(lblNewLabel2);

        lblNewLabel = new JLabel("");
        lblNewLabel.setBounds(1050, -100, 1451, 900);
        lblNewLabel.setIcon(escalarImagen("/imagenes/NPC1.png", 1500, 1000));
        contentPane.add(lblNewLabel);

        // Background del carrito
        JLabel backgroundLabel = new JLabel("");
        backgroundLabel.setBounds(0, 0, screenSize.width, screenSize.height);
        backgroundLabel.setIcon(escalarImagen("/imagenes/Carrito1.png", screenSize.width, screenSize.height));
        contentPane.add(backgroundLabel);

        // Label del texto
        lblNewLabel_1 = new JLabel("");
        lblNewLabel_1.setBackground(SystemColor.text);
        lblNewLabel_1.setVerticalAlignment(SwingConstants.TOP);
        lblNewLabel_1.setForeground(SystemColor.textHighlight);
        lblNewLabel_1.setBounds(100, 30, 1950, 200);
        lblNewLabel_1.setFont(new Font("Cascadia Code", Font.BOLD, 40));
        contentPane.add(lblNewLabel_1);

        // Pancho (al frente de todo)
        panchoLabel = new JLabel(escalarImagen("/imagenes/pancho_vacio.png", 400, 200));
        contentPane.add(panchoLabel);

        // Establecer el orden explícitamente (0 es el frente, números mayores al fondo)
        contentPane.setComponentZOrder(panchoLabel, 0);          // Panchos al frente
        contentPane.setComponentZOrder(lblNewLabel_1, 1);        // Texto después
        contentPane.setComponentZOrder(backgroundLabel, 2);      // Carrito después
        contentPane.setComponentZOrder(lblNewLabel, 3);          // NPC1 al fondo
        contentPane.setComponentZOrder(lblNewLabel2, 3);         // Thiago al fondo

        // Establece el tama�o inicial de la ventana
        setSize(800, 600);

        // Posiciona el label despu�s de que la ventana sea visible
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                int windowWidth = getContentPane().getWidth();
                int windowHeight = getContentPane().getHeight();
                
                panchoLabel.setBounds(
                    (windowWidth - 400) / 2,
                    (windowHeight - (-200)) / 2,
                    400, 
                    200
                );
            }
        });

        contentPane.setComponentZOrder(panchoLabel, 0);

        crearBotonesIngredientes();
        crearBotonEntregarPedido(); // Crear el bot�n para entregar el pedido

        int startX = 1000;
        int finalX = (screenSize.width - 1500) / 2;
        int y = -150;
        
        Timer timer = new Timer(16, new ActionListener() {
            int currentX = startX;
            boolean animacionEntradaCompletada = false;
            
            @Override
            public void actionPerformed(ActionEvent e) {
                int step = 8;
                
                // Animación del primer personaje
                if (!primerPersonajeTermino) {
                    if (!animacionEntradaCompletada) {
                        currentX -= step;
                        if (currentX <= finalX) {
                            currentX = finalX;
                            animacionEntradaCompletada = true;
                            animacionCompletada = true;
                            iniciarAnimacionTexto();
                        }
                    } 
                    else if (dialogmanager1_Acto2.getDialogoActual().equals("CLIENTA: Gracias muy amable")) {
                        currentX -= step;
                        if (currentX <= -1500) {
                            primerPersonajeTermino = true;
                            lblNewLabel.setVisible(false);
                            // Reiniciar posición para el segundo personaje
                            currentX = startX;
                            animacionEntradaCompletada = false;
                            lblNewLabel2.setVisible(true);
                        }
                    }
                    lblNewLabel.setBounds(currentX, y, 1500, 1000);
                }
                // Animación del segundo personaje
                else {
                    if (!animacionEntradaCompletada) {
                        currentX -= step;
                        if (currentX <= finalX) {
                            currentX = finalX;
                            animacionEntradaCompletada = true;
                        }
                    }
                    else if (dialogmanager1_Acto2.getDialogoActual().equals("chau")) {
                        currentX -= step;
                        if (currentX <= -1500) {
                            ((Timer) e.getSource()).stop();
                        }
                    }
                    lblNewLabel2.setBounds(currentX, y, 1500, 1000);
                }
                
                contentPane.revalidate();
                contentPane.repaint();
            }
        });
        
        setSize(screenSize);
        setLocationRelativeTo(null);
        setResizable(false);
        timer.start();
    }

    private void iniciarAnimacionTexto() {
        if (textTimer != null && textTimer.isRunning()) {
            textTimer.stop();
        }

        String textoCompleto = dialogmanager1_Acto2 .getDialogoActual();
        mostrandoTexto = true;

        textTimer = new Timer(50, new ActionListener() {
            int index = 0;
            StringBuilder textoActual = new StringBuilder();

            @Override
            public void actionPerformed(ActionEvent e) {
                if (index < textoCompleto.length()) {
                    textoActual.append(textoCompleto.charAt(index));
                    lblNewLabel_1.setText("<html>" + textoActual.toString().replaceAll("\n", "<br>") + "</html>");
                    index++;
                } else {
                    ((Timer) e.getSource()).stop();
                    mostrandoTexto = false;
                }
            }
        });

        textTimer.start();
    }

    private void crearBotonesIngredientes() {
        String[] ingredientes = {"Pan", "Salchicha", "Mayonesa", "Ketchup", "Mostaza"};

        // MEDIDA 1: Tamaño del botón
        int tamanoBoton = (int)(getContentPane().getWidth() * 0.07);

        // MEDIDA 2: Margen desde el borde izquierdo
        int margenX = (int)(getContentPane().getWidth() * 0.10);

        // Posición Y fija cerca del borde inferior
        int posicionY = (int)(getContentPane().getHeight() * 0.85);

        for (int i = 0; i < ingredientes.length; i++) {
            String ingrediente = ingredientes[i];
            JButton boton;

            // Crear botón con imagen para cada ingrediente
            String rutaImagen = "/ingredientes/" + ingrediente.toUpperCase() + ".png";
            ImageIcon icono = escalarImagen(rutaImagen, tamanoBoton, tamanoBoton);
            boton = new JButton(icono);

            // Configuración visual del botón
            boton.setBorderPainted(false);
            boton.setContentAreaFilled(false);
            boton.setFocusPainted(false);

            boton.addActionListener(e -> agregarIngrediente(ingrediente));

            // Colocar los botones en línea horizontal, aumentando la posición X para cada botón
            int posicionX = margenX + (tamanoBoton + margenX) * i;
            boton.setBounds(posicionX, posicionY, tamanoBoton, tamanoBoton);

            contentPane.add(boton);
            contentPane.setComponentZOrder(boton, 0); // Asegura que el botón quede al frente

        }

        // Listener para hacer responsive los botones
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                // Actualizar el tamaño y posición en la parte inferior al redimensionar la ventana
                int nuevoTamanoBoton = (int)(getContentPane().getWidth() * 0.10);
                int nuevoMargenX = (int)(getContentPane().getWidth() * 0.07);
                int nuevaPosicionY = (int)(getContentPane().getHeight() * 0.85);

                Component[] components = contentPane.getComponents();
                int i = 0;
                for (Component comp : components) {
                    if (comp instanceof JButton) {
                        int nuevoPosicionX = nuevoMargenX + (nuevoTamanoBoton + nuevoMargenX) * i;
                        comp.setBounds(nuevoPosicionX, nuevaPosicionY, nuevoTamanoBoton, nuevoTamanoBoton);
                        i++;
                    }
                }
            }
        });
    }

    private void agregarIngrediente(String ingrediente) {
        switch (ingrediente) {
            case "Pan":
                tienePan = !tienePan;
                break;
            case "Salchicha":
                tieneSalchicha = !tieneSalchicha;
                break;
            case "Mayonesa":
                tieneMayonesa = !tieneMayonesa;
                break;
            case "Ketchup":
                tieneKetchup = !tieneKetchup;
                break;
            case "Mostaza":
                tieneMostaza = !tieneMostaza;
                break;
        }
        actualizarImagenPancho();
    }

    private void actualizarImagenPancho() {
        String imagenRuta = "/imagenes/pancho_vacio.png";

        if (tienePan) {
            imagenRuta = "/imagenes/Pan.png";
        }
        if (tienePan && tieneSalchicha) {
            imagenRuta = "/imagenes/Pancho_Simple.png";
        }
        if (tienePan && tieneSalchicha && tieneMayonesa) {
            imagenRuta = "/imagenes/Pancho_Con_Mayo.png";
        }
        if (tienePan && tieneSalchicha && tieneKetchup) {
            imagenRuta = "/imagenes/Pancho_Con_Ketchup.png";
        }
        if (tienePan && tieneSalchicha && tieneMostaza) {
            imagenRuta = "/imagenes/Pancho_Con_Mostaza.png";
        }
        if (tienePan && tieneSalchicha && tieneMayonesa && tieneKetchup) {
            imagenRuta = "/imagenes/Pancho_Con_MayoYKetchup.png";
        }
        if (tienePan && tieneSalchicha && tieneMayonesa && tieneMostaza) {
            imagenRuta = "/imagenes/Pancho_Con_MayoYMostaza.png";
        }
        if (tienePan && tieneSalchicha && tieneMostaza && tieneKetchup) {
            imagenRuta = "/imagenes/Pancho_Con_MostazaYKetchup.png";
        }
        if (tienePan && tieneSalchicha && tieneMostaza && tieneKetchup && tieneMayonesa) {
            imagenRuta = "/imagenes/Pancho_Con_Todo.png";
        }

        panchoLabel.setIcon(escalarImagen(imagenRuta, 1600, 800));
    }

    private void crearBotonEntregarPedido() {
        btnEntregarPedido = new JButton("Entregar Pedido");
        btnEntregarPedido.setBounds(100, 350, 200, 50);
        btnEntregarPedido.setFont(new Font("Cascadia Code", Font.BOLD, 20));

        btnEntregarPedido.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                entregarPedido();
            }
        });

        contentPane.add(btnEntregarPedido);
        
        lblNewLabel_2 = new JLabel("");
        lblNewLabel_2.setIcon(new ImageIcon(Episodio1_Acto2.class.getResource("/imagenes/fondoplaya.png")));
        lblNewLabel_2.setBounds(0, 0, 1920, 1080);
        contentPane.add(lblNewLabel_2);
    }
    private void reiniciarIngredientes() {
        // Reiniciar las variables de los ingredientes
        tienePan = false;
        tieneSalchicha = false;
        tieneKetchup = false;
        tieneMayonesa = false;
        tieneMostaza = false;
    }


    private boolean verificarPedido(List<String> pedidoActual) {
        if (pedidoActual == null || pedidoActual.isEmpty()) {
            return false;
        }

        String[] pedidoEsperado = dialogmanager1_Acto2.getPedidoEsperado();

        // Depuración
        System.out.println("Pedido actual: " + pedidoActual);
        System.out.println("Pedido esperado: " + Arrays.toString(pedidoEsperado));

        if (pedidoActual.size() != pedidoEsperado.length) {
            return false;
        }

        for (int i = 0; i < pedidoEsperado.length; i++) {
            if (!pedidoActual.get(i).equals(pedidoEsperado[i])) {
                return false;
            }
        }

        return true;
    }

    // Método entregarPedido modificado
    private void entregarPedido() {
        List<String> pedidoActual = dialogmanager1_Acto2.getPedidoEnProceso();
        boolean pedidoCorrecto = verificarPedido(pedidoActual);

        if (pedidoCorrecto) {
            panchoLabel.setVisible(false);
            reiniciarIngredientes();
            dialogmanager1_Acto2.avanzarCliente();
            panchoLabel.setVisible(true);
            actualizarImagenPancho();
            dialogmanager1_Acto2.reanudarDialogos(true);
            
            if (dialogmanager1_Acto2.siguienteDialogo()) {
                iniciarAnimacionTexto();
            }
        } else {
            JOptionPane.showMessageDialog(this, 
                "El pedido no es correcto. Por favor, revisa los ingredientes.",
                "Pedido Incorrecto",
                JOptionPane.WARNING_MESSAGE);
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {}
    @Override
    public void keyReleased(KeyEvent e) {}
    @Override
    public void keyTyped(KeyEvent e) {}
}
