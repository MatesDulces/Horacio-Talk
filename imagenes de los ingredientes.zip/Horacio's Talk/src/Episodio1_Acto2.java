import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.net.URL;
import java.util.Arrays;

public class Episodio1_Acto2 extends JFrame implements KeyListener {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JLabel lblNewLabel_1;
    private Timer textTimer;
    private DialogManager1_Acto2 dialogmanager1_Acto2;
    private boolean mostrandoTexto = false;
    private boolean animacionCompletada = false;
    private JLabel panchoLabel; // JLabel para mostrar el pancho
    private boolean tienePan = false;
    private boolean tieneSalchicha = false;
    private boolean tieneMayonesa = false;
    private boolean tieneKetchup = false;
    private boolean tieneMostaza = false;
    private JButton btnEntregarPedido; // Bot�n para entregar el pedido
    private JLabel lblNewLabel_2;

    private ImageIcon escalarImagen(String ruta, int ancho, int alto) {
        URL imgUrl = Episodio1_Acto2.class.getResource(ruta);
        if (imgUrl == null) {
            System.err.println("Error: La imagen no se pudo encontrar en la ruta: " + ruta);
            return null; // o puedes retornar una imagen por defecto aqu�
        }
        ImageIcon imagenOriginal = new ImageIcon(imgUrl);
        Image imagen = imagenOriginal.getImage();
        Image imagenEscalada = imagen.getScaledInstance(ancho, alto, Image.SCALE_SMOOTH);
        return new ImageIcon(imagenEscalada);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Episodio1_Acto2 frame = new Episodio1_Acto2();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Episodio1_Acto2() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true);
        addKeyListener(this);
        setFocusable(true);

        dialogmanager1_Acto2 = new DialogManager1_Acto2();

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.window);
        contentPane.setBorder(null);
        setContentPane(contentPane);
        contentPane.setPreferredSize(screenSize);
        contentPane.setSize(screenSize);
        contentPane.setLayout(null);

        contentPane.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (!animacionCompletada) return;

                if (mostrandoTexto) {
                    textTimer.stop();
                    lblNewLabel_1.setText("<html>" + dialogmanager1_Acto2 .getDialogoActual().replaceAll("\n", "<br>") + "</html>");
                    mostrandoTexto = false;
                } else {
                    if (dialogmanager1_Acto2 .hayMasDialogos()) {
                    	dialogmanager1_Acto2 .siguienteDialogo();
                        iniciarAnimacionTexto();
                    }
                }
            }
        });

        JLabel lblNewLabel = new JLabel("");
        lblNewLabel.setBounds(1050, -100, 1451, 900);
        lblNewLabel.setIcon(escalarImagen("/imagenes/NPC1.png", 1500, 1000));
        contentPane.add(lblNewLabel);

        JLabel backgroundLabel = new JLabel("");
        backgroundLabel.setBounds(0, 0, screenSize.width, screenSize.height);
        backgroundLabel.setIcon(escalarImagen("/imagenes/Carrito.png", screenSize.width, screenSize.height));
        contentPane.add(backgroundLabel);

        lblNewLabel_1 = new JLabel("");
        lblNewLabel_1.setBackground(SystemColor.text);
        lblNewLabel_1.setVerticalAlignment(SwingConstants.TOP);
        lblNewLabel_1.setForeground(SystemColor.textHighlight);
        lblNewLabel_1.setBounds(100, 30, 1950, 200);
        lblNewLabel_1.setFont(new Font("Cascadia Code", Font.BOLD, 40));
        contentPane.add(lblNewLabel_1);

        contentPane.setComponentZOrder(lblNewLabel, contentPane.getComponentCount() - 1);
        contentPane.setComponentZOrder(backgroundLabel, contentPane.getComponentCount() - 2);

        panchoLabel = new JLabel(escalarImagen("/imagenes/pancho_vacio.png", 400, 200));
        contentPane.add(panchoLabel);

        // Establece el tama�o inicial de la ventana
        setSize(800, 600);

        // Posiciona el label despu�s de que la ventana sea visible
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                int windowWidth = getContentPane().getWidth();
                int windowHeight = getContentPane().getHeight();
                
                panchoLabel.setBounds(
                    (windowWidth - 400) / 2,
                    (windowHeight - (-200)) / 2,
                    400, 
                    200
                );
            }
        });

        contentPane.setComponentZOrder(panchoLabel, 0);

        crearBotonesIngredientes();
        crearBotonEntregarPedido(); // Crear el bot�n para entregar el pedido

        int startX = 1000;
        int finalX = (screenSize.width - 1500) / 2;
        int y = -150;

        Timer timer = new Timer(16, new ActionListener() {
            int currentX = startX;

            @Override
            public void actionPerformed(ActionEvent e) {
                int step = 8;
                currentX -= step;

                if (currentX <= finalX) {
                    currentX = finalX;
                    ((Timer) e.getSource()).stop();
                    animacionCompletada = true;
                    iniciarAnimacionTexto();
                }

                lblNewLabel.setBounds(currentX, y, 1500, 1000);
                contentPane.revalidate();
                contentPane.repaint();
            }
        });

        setSize(screenSize);
        setLocationRelativeTo(null);
        setResizable(false);

        timer.start();
    }

    private void iniciarAnimacionTexto() {
        if (textTimer != null && textTimer.isRunning()) {
            textTimer.stop();
        }

        String textoCompleto = dialogmanager1_Acto2 .getDialogoActual();
        mostrandoTexto = true;

        textTimer = new Timer(50, new ActionListener() {
            int index = 0;
            StringBuilder textoActual = new StringBuilder();

            @Override
            public void actionPerformed(ActionEvent e) {
                if (index < textoCompleto.length()) {
                    textoActual.append(textoCompleto.charAt(index));
                    lblNewLabel_1.setText("<html>" + textoActual.toString().replaceAll("\n", "<br>") + "</html>");
                    index++;
                } else {
                    ((Timer) e.getSource()).stop();
                    mostrandoTexto = false;
                }
            }
        });

        textTimer.start();
    }

    private void crearBotonesIngredientes() {
        String[] ingredientes = {"Pan", "Salchicha", "Mayonesa", "Ketchup", "Mostaza"};

        // MEDIDA 1: Tamaño del botón
        int tamanoBoton = (int)(getContentPane().getWidth() * 0.07);

        // MEDIDA 2: Margen desde el borde izquierdo
        int margenX = (int)(getContentPane().getWidth() * 0.10);

        // Posición Y fija cerca del borde inferior
        int posicionY = (int)(getContentPane().getHeight() * 0.85);

        for (int i = 0; i < ingredientes.length; i++) {
            String ingrediente = ingredientes[i];
            JButton boton;

            // Crear botón con imagen para cada ingrediente
            String rutaImagen = "/ingredientes/" + ingrediente.toUpperCase() + ".png";
            ImageIcon icono = escalarImagen(rutaImagen, tamanoBoton, tamanoBoton);
            boton = new JButton(icono);

            // Configuración visual del botón
            boton.setBorderPainted(false);
            boton.setContentAreaFilled(false);
            boton.setFocusPainted(false);

            boton.addActionListener(e -> agregarIngrediente(ingrediente));

            // Colocar los botones en línea horizontal, aumentando la posición X para cada botón
            int posicionX = margenX + (tamanoBoton + margenX) * i;
            boton.setBounds(posicionX, posicionY, tamanoBoton, tamanoBoton);

            contentPane.add(boton);
            contentPane.setComponentZOrder(boton, 0); // Asegura que el botón quede al frente

        }

        // Listener para hacer responsive los botones
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                // Actualizar el tamaño y posición en la parte inferior al redimensionar la ventana
                int nuevoTamanoBoton = (int)(getContentPane().getWidth() * 0.10);
                int nuevoMargenX = (int)(getContentPane().getWidth() * 0.07);
                int nuevaPosicionY = (int)(getContentPane().getHeight() * 0.85);

                Component[] components = contentPane.getComponents();
                int i = 0;
                for (Component comp : components) {
                    if (comp instanceof JButton) {
                        int nuevoPosicionX = nuevoMargenX + (nuevoTamanoBoton + nuevoMargenX) * i;
                        comp.setBounds(nuevoPosicionX, nuevaPosicionY, nuevoTamanoBoton, nuevoTamanoBoton);
                        i++;
                    }
                }
            }
        });
    }

    private void agregarIngrediente(String ingrediente) {
        switch (ingrediente) {
            case "Pan":
                tienePan = !tienePan;
                break;
            case "Salchicha":
                tieneSalchicha = !tieneSalchicha;
                break;
            case "Mayonesa":
                tieneMayonesa = !tieneMayonesa;
                break;
            case "Ketchup":
                tieneKetchup = !tieneKetchup;
                break;
            case "Mostaza":
                tieneMostaza = !tieneMostaza;
                break;
        }
        actualizarImagenPancho();
    }

    private void actualizarImagenPancho() {
        String imagenRuta = "/imagenes/pancho_vacio.png";

        if (tienePan) {
            imagenRuta = "/imagenes/Pan.png";
        }
        if (tienePan && tieneSalchicha) {
            imagenRuta = "/imagenes/Pancho_Simple.png";
        }
        if (tienePan && tieneSalchicha && tieneMayonesa) {
            imagenRuta = "/imagenes/Pancho_Con_Mayo.png";
        }
        if (tienePan && tieneSalchicha && tieneKetchup) {
            imagenRuta = "/imagenes/Pancho_Con_Ketchup.png";
        }
        if (tienePan && tieneSalchicha && tieneMostaza) {
            imagenRuta = "/imagenes/Pancho_Con_Mostaza.png";
        }
        if (tienePan && tieneSalchicha && tieneMayonesa && tieneKetchup) {
            imagenRuta = "/imagenes/Pancho_Con_MayoYKetchup.png";
        }
        if (tienePan && tieneSalchicha && tieneMayonesa && tieneMostaza) {
            imagenRuta = "/imagenes/Pancho_Con_MayoYMostaza.png";
        }
        if (tienePan && tieneSalchicha && tieneMostaza && tieneKetchup) {
            imagenRuta = "/imagenes/Pancho_Con_MostazaYKetchup.png";
        }
        if (tienePan && tieneSalchicha && tieneMostaza && tieneKetchup && tieneMayonesa) {
            imagenRuta = "/imagenes/Pancho_Con_Todo.png";
        }

        panchoLabel.setIcon(escalarImagen(imagenRuta, 1600, 800));
    }

    private void crearBotonEntregarPedido() {
        btnEntregarPedido = new JButton("Entregar Pedido");
        btnEntregarPedido.setBounds(100, 350, 200, 50);
        btnEntregarPedido.setFont(new Font("Cascadia Code", Font.BOLD, 20));

        btnEntregarPedido.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                entregarPedido();
            }
        });

        contentPane.add(btnEntregarPedido);
        
        lblNewLabel_2 = new JLabel("");
        lblNewLabel_2.setIcon(new ImageIcon(Episodio1_Acto2.class.getResource("/imagenes/fondoplaya.png")));
        lblNewLabel_2.setBounds(0, 0, 1920, 1080);
        contentPane.add(lblNewLabel_2);
    }

    private void entregarPedido() {
        // Definir pedidoCorrecto como final para poder usarlo en el timer
        final boolean pedidoCorrecto = tienePan && tieneKetchup && tieneSalchicha && !tieneMayonesa && !tieneMostaza;

        // Obtener el di�logo dependiendo si el pedido es correcto o no
        String dialogoPedido = dialogmanager1_Acto2 .obtenerDialogoPedido(pedidoCorrecto);

        // Mostrar el di�logo en la interfaz gr�fica
        lblNewLabel_1.setText("<html>" + dialogoPedido.replaceAll("\n", "<br>") + "</html>");

        // Esperamos un poco antes de continuar con el siguiente di�logo (opcional)
        Timer timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Continuar con el siguiente di�logo solo si el pedido es correcto
                if (pedidoCorrecto) {
                	dialogmanager1_Acto2 .reanudarDialogos(pedidoCorrecto); // Reanudar di�logos
                    if (dialogmanager1_Acto2 .siguienteDialogo()) {
                        // Iniciar la animaci�n del siguiente di�logo
                        iniciarAnimacionTexto();
                    }
                } else {
                    // Si el pedido no es correcto, podemos mantener el di�logo actual
                    // Aqu� no avanzamos el di�logo, simplemente mostramos que el pedido es incorrecto
                }
            }
        });
        timer.setRepeats(false);
        timer.start();
    }





    @Override
    public void keyPressed(KeyEvent e) {}
    @Override
    public void keyReleased(KeyEvent e) {}
    @Override
    public void keyTyped(KeyEvent e) {}
}
