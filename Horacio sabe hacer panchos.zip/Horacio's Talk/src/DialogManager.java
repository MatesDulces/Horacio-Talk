public class DialogManager {
    private String[] dialogos;
    private int dialogoActual;
    
    public DialogManager() {
        // Aqu� puedes agregar todos los di�logos de la conversaci�n
        dialogos = new String[]{
            "HORACIO: A Mi primera clienta\n*Horacio se pone atento para la posible venta*",
            "CLIENTA: Buenos dias, ¿tiene pasteles frescos?",
            "HORACIO: !Por supuesto! Recien horneados esta mañana",
            // Puedes agregar m�s di�logos aqu�
        };
        dialogoActual = 0;
    }
    
    public String getDialogoActual() {
        if (dialogoActual < dialogos.length) {
            return dialogos[dialogoActual];
        }
        return "";
    }
    
    public boolean siguienteDialogo() {
        if (dialogoActual < dialogos.length - 1) {
            dialogoActual++;
            return true;
        }
        return false;
    }
    
    public boolean hayMasDialogos() {
        return dialogoActual < dialogos.length - 1;
    }
    
    public void reiniciarDialogos() {
        dialogoActual = 0;
    }
}