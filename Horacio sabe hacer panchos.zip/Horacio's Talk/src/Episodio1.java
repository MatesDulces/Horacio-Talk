import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.net.URL;

public class Episodio1 extends JFrame implements KeyListener {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JLabel lblNewLabel_1;
    private Timer textTimer;
    private DialogManager dialogManager;
    private boolean mostrandoTexto = false;
    private boolean animacionCompletada = false;
    private JLabel panchoLabel; // JLabel para mostrar el pancho
    private boolean tienePan = false;
    private boolean tieneSalchicha = false;
    private boolean tieneMayonesa = false;
    private boolean tieneKetchup = false;
    private boolean tieneMostaza = false;

    private ImageIcon escalarImagen(String ruta, int ancho, int alto) {
        URL imgUrl = Episodio1.class.getResource(ruta);
        if (imgUrl == null) {
            System.err.println("Error: La imagen no se pudo encontrar en la ruta: " + ruta);
            return null; // o puedes retornar una imagen por defecto aquí
        }
        ImageIcon imagenOriginal = new ImageIcon(imgUrl);
        Image imagen = imagenOriginal.getImage();
        Image imagenEscalada = imagen.getScaledInstance(ancho, alto, Image.SCALE_SMOOTH);
        return new ImageIcon(imagenEscalada);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Episodio1 frame = new Episodio1();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Episodio1() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true);
        addKeyListener(this);
        setFocusable(true);

        dialogManager = new DialogManager();

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.window);
        contentPane.setBorder(null);
        setContentPane(contentPane);
        contentPane.setPreferredSize(screenSize);
        contentPane.setSize(screenSize);
        contentPane.setLayout(null);

        // Añadir el MouseListener al contentPane
        contentPane.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (!animacionCompletada) return;

                if (mostrandoTexto) {
                    // Si se está mostrando texto, mostrarlo completo inmediatamente
                    textTimer.stop();
                    lblNewLabel_1.setText("<html>" + dialogManager.getDialogoActual().replaceAll("\n", "<br>") + "</html>");
                    mostrandoTexto = false;
                } else {
                    // Si no se está mostrando texto, avanzar al siguiente diálogo
                    if (dialogManager.hayMasDialogos()) {
                        dialogManager.siguienteDialogo();
                        iniciarAnimacionTexto();
                    }
                }
            }
        });

        // Configurar el fondo y otros elementos gráficos
        JLabel lblNewLabel = new JLabel("");
        lblNewLabel.setBounds(1050, -100, 1451, 900);
        lblNewLabel.setIcon(escalarImagen("/imagenes/lachinacreoquefunciona.png", 1500, 1000));
        contentPane.add(lblNewLabel);

        JLabel backgroundLabel = new JLabel("");
        backgroundLabel.setBounds(0, 0, screenSize.width, screenSize.height);
        backgroundLabel.setIcon(escalarImagen("/imagenes/Carrito.png", screenSize.width, screenSize.height));
        contentPane.add(backgroundLabel);

        lblNewLabel_1 = new JLabel("");
        lblNewLabel_1.setBackground(SystemColor.text);
        lblNewLabel_1.setVerticalAlignment(SwingConstants.TOP);
        lblNewLabel_1.setForeground(SystemColor.textHighlight);
        lblNewLabel_1.setBounds(100, 30, 1950, 200);
        lblNewLabel_1.setFont(new Font("Cascadia Code", Font.BOLD, 40));
        contentPane.add(lblNewLabel_1);

        contentPane.setComponentZOrder(lblNewLabel, contentPane.getComponentCount() - 1);
        contentPane.setComponentZOrder(backgroundLabel, contentPane.getComponentCount() - 2);

        // JLabel para mostrar el pancho
        panchoLabel = new JLabel(escalarImagen("/imagenes/pancho_vacio.png", 400, 200)); // Imagen base
        panchoLabel.setBounds(750, 700, 400, 200);
        contentPane.add(panchoLabel);

        // Asegurarse de que el pancho esté al frente
        contentPane.setComponentZOrder(panchoLabel, 0); // Mover el panchoLabel al frente

        // Crear botones para los ingredientes
        crearBotonesIngredientes();

        // Animación de movimiento ajustada
        int startX = 1000;
        int finalX = (screenSize.width - 1500) / 2; // Ajusta el tamaño del label
        int y = -150;

        Timer timer = new Timer(16, new ActionListener() {
            int currentX = startX;

            @Override
            public void actionPerformed(ActionEvent e) {
                int step = 8; // Ajustado para que sea más lento
                currentX -= step;

                if (currentX <= finalX) {
                    currentX = finalX;
                    ((Timer) e.getSource()).stop();
                    animacionCompletada = true;
                    iniciarAnimacionTexto(); // Iniciar la animación del texto cuando termine el movimiento
                }

                lblNewLabel.setBounds(currentX, y, 1500, 1000);
                contentPane.revalidate();
                contentPane.repaint();
            }
        });

        setSize(screenSize);
        setLocationRelativeTo(null);
        setResizable(false);

        timer.start();
    }

    private void iniciarAnimacionTexto() {
        if (textTimer != null && textTimer.isRunning()) {
            textTimer.stop();
        }

        String textoCompleto = dialogManager.getDialogoActual();
        mostrandoTexto = true;

        textTimer = new Timer(50, new ActionListener() {
            int index = 0;
            StringBuilder textoActual = new StringBuilder();

            @Override
            public void actionPerformed(ActionEvent e) {
                if (index < textoCompleto.length()) {
                    textoActual.append(textoCompleto.charAt(index));
                    lblNewLabel_1.setText("<html>" + textoActual.toString().replaceAll("\n", "<br>") + "</html>");
                    index++;
                } else {
                    ((Timer) e.getSource()).stop();
                    mostrandoTexto = false;
                }
            }
        });

        textTimer.start();
    }

    private void crearBotonesIngredientes() {
        // Botones para los ingredientes
        String[] ingredientes = {"Pan", "Salchicha", "Mayonesa", "Ketchup", "Mostaza"};
        for (String ingrediente : ingredientes) {
            JButton boton = new JButton(ingrediente);
            boton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    agregarIngrediente(ingrediente);
                }
            });
            // Agregar los botones a la interfaz
            contentPane.add(boton);
            // Ajustar la posición de los botones
            boton.setBounds(100, 200 + (30 * (java.util.Arrays.asList(ingredientes).indexOf(ingrediente))), 100, 25);
        }
    }

    private void agregarIngrediente(String ingrediente) {
        switch (ingrediente) {
            case "Pan":
                tienePan = !tienePan; // Alternar estado
                break;
            case "Salchicha":
                tieneSalchicha = !tieneSalchicha; // Alternar estado
                break;
            case "Mayonesa":
                tieneMayonesa = !tieneMayonesa; // Alternar estado
                break;
            case "Ketchup":
                tieneKetchup = !tieneKetchup; // Alternar estado
                break;
            case "Mostaza":
                tieneMostaza = !tieneMostaza; // Alternar estado
                break;
        }
        // Cambiar la imagen del pancho según los ingredientes
        actualizarImagenPancho();
    }

    private void actualizarImagenPancho() {
        // Determinar la imagen del pancho según los ingredientes seleccionados
        String imagenRuta = "/imagenes/pancho_vacio.png"; // Imagen base

        // Lógica para determinar la imagen según los ingredientes
        if (tienePan) {
            imagenRuta = "/imagenes/Pan.png";
        }
        if (tienePan && tieneSalchicha) {
            imagenRuta = "/imagenes/Pancho_Simple.png"; // Imagen con salchicha
        }
        if (tienePan && tieneSalchicha && tieneMayonesa) {
            imagenRuta = "/imagenes/Pancho_Con_Mayo.png"; // Imagen con salchicha y mayonesa
        }
        if (tienePan && tieneSalchicha && tieneKetchup) {
            imagenRuta = "/imagenes/Pancho_Con_Ketchup.png"; // Imagen con salchicha y ketchup
        }
        if (tienePan && tieneSalchicha && tieneMostaza) {
            imagenRuta = "/imagenes/Pancho_Con_Mostaza.png"; // Imagen con salchicha y mostaza
        }
        if (tienePan && tieneSalchicha && tieneMayonesa && tieneKetchup) {
            imagenRuta = "/imagenes/Pancho_Con_MayoYKetchup.png"; // Imagen con salchicha, mayonesa y ketchup
        }
        if (tienePan && tieneSalchicha && tieneMayonesa && tieneMostaza) {
            imagenRuta = "/imagenes/Pancho_Con_MayoYMostaza.png"; // Imagen con salchicha, mayonesa y mostaza
        }
        if (tienePan && tieneSalchicha && tieneMostaza && tieneKetchup) {
            imagenRuta = "/imagenes/Pancho_Con_MostazaYKetchup.png"; // Imagen con salchicha, mayonesa y mostaza
        }
        if (tienePan && tieneSalchicha && tieneMostaza && tieneKetchup && tieneMayonesa) {
            imagenRuta = "/imagenes/Pancho_Con_Todo.png"; // Imagen con salchicha, mayonesa y mostaza
        }
        // Agregar más combinaciones según sea necesario

        // Cambiar la imagen del panchoLabel
        panchoLabel.setIcon(escalarImagen(imagenRuta, 1600, 800));
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyPressed(KeyEvent e) {}

    @Override
    public void keyReleased(KeyEvent e) {}
}
