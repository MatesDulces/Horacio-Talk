public class DialogManager3 {
    private String[] dialogos;
    private int dialogoActual;
    private boolean debeAnimar = false;
    private boolean enPausa = false;
    private int pedidoActual = 1;

    public DialogManager3() {
        dialogos = new String[]{
            "HORACIO: tesgrterte",
            "*Horacio se emociona para atender a la joven que llega*",
            "CLIENTA: Hola buen dia, ¿te puedo pedir un pancho con ketchup?",
            "CLIENTA: Soy alergico a la moztaza y la mayo asi que el pancho solito asi",
            "HORACIO: (Que raro que es este tipo encima con pelo azul), si señor ya va",
            //PAUSA
            "CLIENTA: Gracias maestro",
            "CLIENTA: Hola buen dia, te puedo pedir un pancho con todo lo que tengas?",
            "CLIENTA: Con ketchup, mostaza yyy... em ¿mayonesa?, em no mejor sin eso",
            "HORACIO: (Si van a empezar a ser todos raros cierro el local), \n Si joven ya va...",
            //PAUSA
            "CLIENTE  Emm me llamo Hernan",
            "HERNAN:  Bueno.. sos de aca? ",
            "HORACIO: No, soy de San Bernardo",
            "HORACIO: ¿Vos sos de aca Hernan?",
            "HERNAN:  Em no, yo soy de Buenos Aires",
            "HORACIO: Estamos en Buenos Aires...",
            "HORACIO: Bueno pibe, ¿dejas pasar a la gente que quiere comprar?",
            "HERNAN:  Bueno viejo perdoname",
            "HERNAN:  Hola buen dia, te puedo pedir un pancho con todo?", // Nuevo diálogo para el tercer pedido
            "HORACIO: (Ya van tres raros seguidos...) Si, ya te lo preparo",
            //PAUSA
            "HERNAN:  Bueno viejo perdoname1"
            
        };
        dialogoActual = 0;
    }


    // Obtiene el diálogo actual
    public String getDialogoActual() {
        if (dialogoActual < dialogos.length) {
            return dialogos[dialogoActual];
        }
        return "";
    }

    // Avanza al siguiente diálogo
    public boolean siguienteDialogo() {
        if (enPausa) {
            return false;
        }
        if (dialogoActual < dialogos.length - 1) {
            dialogoActual++;
            // Activa la pausa según el pedido actual
            if (pedidoActual == 1 && dialogoActual == 4) {
                enPausa = true;
            } else if (pedidoActual == 2 && dialogoActual == 8) {
                enPausa = true;
            } else if (pedidoActual == 3 && dialogoActual == 18) { // Nueva pausa para el tercer pedido
                enPausa = true;
            }
            // Activa la animación en momentos específicos
            if (dialogos[dialogoActual].equals("CLIENTA: Gracias maestro") ||
                dialogos[dialogoActual].equals("CLIENTE  Emm me llamo Hernan")) {
                debeAnimar = true;
            }
            return true;
        }
        return false;
    }

    // Verifica si debe animar
    public boolean debeAnimar() {
        return debeAnimar;
    }

    // Resetea la animación
    public void resetearAnimacion() {
        debeAnimar = false;
    }

    // Obtiene el pedido actual
    public int getPedidoActual() {
        return pedidoActual;
    }

    // Avanza al siguiente pedido
    public void avanzarPedido() {
        pedidoActual++;
    }

    // Reanuda los diálogos si el pedido es correcto
    public void reanudarDialogos(boolean pedidoCorrecto) {
        if (pedidoCorrecto) {
            enPausa = false;
        }
    }

    // Verifica si hay más diálogos
    public boolean hayMasDialogos() {
        return dialogoActual < dialogos.length - 1;
    }

    // Reinicia todos los diálogos
    public void reiniciarDialogos() {
        dialogoActual = 0;
        pedidoActual = 1;
        debeAnimar = false;
        enPausa = false;
    }

    // Obtiene el diálogo correspondiente según el estado del pedido
    public String obtenerDialogoPedido(boolean pedidoCorrecto) {
        switch(pedidoActual) {
            case 1:
                if (pedidoCorrecto) {
                    return "HORACIO: Aca tenes tu pancho con ketchup.";
                } else {
                    return "CLIENTE: ME QUERES MATAR??, SOY ALERGICO A LA MOSTAZA Y MAYONESA";
                }
            case 2:
                if (pedidoCorrecto) {
                    return "HORACIO: Tu pancho pibe con ketchup y moztaza.";
                } else {
                    return "HORACIO: (Em.. Creo que no es lo que me pidio, ¿¿¿que habia pedido???) ";
                }
            case 3:
                if (pedidoCorrecto) {
                    return "HORACIO: Acá tenés tu pancho completo con todo.";
                } else {
                    return "HORACIO: (Este chico dijo con todo... ¿no?)";
                }
            default:
                return "";
        }
    }

    // Verifica si el diálogo está en pausa
    public boolean estaEnPausa() {
        return enPausa;
    }

    // Establece el estado de pausa
    public void setPausa(boolean pausa) {
        this.enPausa = pausa;
    }

    // Obtiene el índice del diálogo actual
    public int getIndiceDialogoActual() {
        return dialogoActual;
    }

    // Establece el índice del diálogo actual
    public void setIndiceDialogoActual(int indice) {
        if (indice >= 0 && indice < dialogos.length) {
            this.dialogoActual = indice;
        }
    }

    // Obtiene la cantidad total de diálogos
    public int getCantidadDialogos() {
        return dialogos.length;
    }

    // Verifica si es el último diálogo
    public boolean esUltimoDialogo() {
        return dialogoActual == dialogos.length - 1;
    }

    // Obtiene el diálogo por índice
    public String getDialogo(int indice) {
        if (indice >= 0 && indice < dialogos.length) {
            return dialogos[indice];
        }
        return "";
    }

    // Retrocede al diálogo anterior
    public boolean dialogoAnterior() {
        if (dialogoActual > 0) {
            dialogoActual--;
            return true;
        }
        return false;
    }
}