import java.awt.Container;
import java.awt.Graphics;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class ImagenH extends JFrame {
    private static final long serialVersionUID = 1L;
    
    public ImagenH() {
        // Configurar el frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setUndecorated(true); // Elimina la decoraci�n de la ventana
    }

    @Override
    public void setVisible(boolean b) {
        // Cargar la imagen de fondo
        ImageIcon backgroundImage = new ImageIcon(Home.class.getResource("/ingredientes/HoracioDespertar.png"));
        
        // Crear el panel donde se dibujar� la imagen
        JPanel contentPane = new JPanel() {
            private static final long serialVersionUID = 1L;
            
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                
                // Dibujar la imagen de fondo ajustada al tama�o del panel
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage.getImage(), 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        
        // Configuraci�n del contenedor
        contentPane.setLayout(null);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        
        // Configurar pantalla completa
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        GraphicsDevice gd = ge.getDefaultScreenDevice();
        
        if (gd.isFullScreenSupported()) {
            gd.setFullScreenWindow(this);
        } else {
            // Si no se soporta el modo pantalla completa, maximizar la ventana
            setExtendedState(JFrame.MAXIMIZED_BOTH);
        }
        
        super.setVisible(b);
    }
    
    // M�todo main para probar la clase
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            new ImagenH().setVisible(true);
        });
    }
}