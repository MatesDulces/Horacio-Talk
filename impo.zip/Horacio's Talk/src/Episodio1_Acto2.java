import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;

import javax.swing.*;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
//pedidos de panchos
public class Episodio1_Acto2 extends JFrame implements KeyListener {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JLabel lblNewLabel_1;
    private Timer textTimer;
    private DialogManager1_Acto2 dialogmanager1_Acto2;
    private boolean mostrandoTexto = false;
    private boolean animacionCompletada = false;
    private JLabel panchoLabel; // JLabel para mostrar el pancho
    private boolean tienePan = false;
    private boolean tieneSalchicha = false;
    private boolean tieneMayonesa = false;
    private boolean tieneKetchup = false;
    private boolean tieneMostaza = false;
    private JButton btnEntregarPedido; // Bot�n para entregar el pedido
    private JLabel lblNewLabel; // Para NPC1
    private JLabel lblNewLabel2; // Para Thiago
    private JLabel lblNewLabel3; // Para Thiago
    private boolean primerPersonajeTermino = false;
    
    private ImageIcon escalarImagen(String ruta, int ancho, int alto) {
        URL imgUrl = Episodio1_Acto2.class.getResource(ruta);
        if (imgUrl == null) {
            System.err.println("Error: La imagen no se pudo encontrar en la ruta: " + ruta);
            return null; // o puedes retornar una imagen por defecto aqu�
        }
        ImageIcon imagenOriginal = new ImageIcon(imgUrl);
        Image imagen = imagenOriginal.getImage();
        Image imagenEscalada = imagen.getScaledInstance(ancho, alto, Image.SCALE_SMOOTH);
        return new ImageIcon(imagenEscalada);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Episodio1_Acto2 frame = new Episodio1_Acto2();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Episodio1_Acto2() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true);
        addKeyListener(this);
        setFocusable(true);

        dialogmanager1_Acto2 = new DialogManager1_Acto2();

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.window);
        contentPane.setBorder(null);
        setContentPane(contentPane);
        contentPane.setPreferredSize(screenSize);
        contentPane.setSize(screenSize);
        contentPane.setLayout(null);

        contentPane.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (!animacionCompletada) return;

                if (mostrandoTexto) {
                    textTimer.stop();
                    lblNewLabel_1.setText("<html>" + dialogmanager1_Acto2 .getDialogoActual().replaceAll("\n", "<br>") + "</html>");
                    mostrandoTexto = false;
                } else {
                    if (dialogmanager1_Acto2 .hayMasDialogos()) {
                    	dialogmanager1_Acto2 .siguienteDialogo();
                        iniciarAnimacionTexto();
                    }
                }
            }
        });
     // Labels de personajes (al fondo)
        lblNewLabel3 = new JLabel("");
        lblNewLabel3.setBounds(1050, -100, 1451, 900);
        lblNewLabel3.setIcon(escalarImagen("/imagenes/Famoso.png", 1500, 1000));
        lblNewLabel3.setVisible(false);
        contentPane.add(lblNewLabel3);
        
        lblNewLabel2 = new JLabel("");
        lblNewLabel2.setBounds(1050, -100, 1451, 900);
        lblNewLabel2.setIcon(escalarImagen("/imagenes/Thiago.png", 1500, 1000));
        lblNewLabel2.setVisible(false);
        contentPane.add(lblNewLabel2);

        lblNewLabel = new JLabel("");
        lblNewLabel.setBounds(1050, -100, 1451, 900);
        lblNewLabel.setIcon(escalarImagen("/imagenes/NPC1.png", 1500, 1000));
        contentPane.add(lblNewLabel);

        // Background del carrito
        JLabel backgroundLabel = new JLabel("");
        backgroundLabel.setBounds(0, 0, screenSize.width, screenSize.height);
        backgroundLabel.setIcon(escalarImagen("/imagenes/CarritoConSalchicha.png", screenSize.width, screenSize.height));
        contentPane.add(backgroundLabel);

        // Label del texto
        lblNewLabel_1 = new JLabel("");
        lblNewLabel_1.setBackground(SystemColor.text);
        lblNewLabel_1.setVerticalAlignment(SwingConstants.TOP);
        lblNewLabel_1.setForeground(SystemColor.textHighlight);
        lblNewLabel_1.setBounds(100, 30, 1950, 200);
        lblNewLabel_1.setFont(new Font("Cascadia Code", Font.BOLD, 40));
        contentPane.add(lblNewLabel_1);

        // Pancho (al frente de todo)
        panchoLabel = new JLabel(escalarImagen("/imagenes/pancho_vacio.png", 400, 200));
        contentPane.add(panchoLabel);

        // Establecer el orden explícitamente (0 es el frente, números mayores al fondo)
        contentPane.setComponentZOrder(panchoLabel, 0);          // Panchos al frente
        contentPane.setComponentZOrder(lblNewLabel_1, 1);        // Texto después
        contentPane.setComponentZOrder(backgroundLabel, 2);      // Carrito después
        contentPane.setComponentZOrder(lblNewLabel, 3);          // NPC1 al fondo
        contentPane.setComponentZOrder(lblNewLabel2, 3);         // Thiago al fondo
        contentPane.setComponentZOrder(lblNewLabel3, 3);         // Thiago al fondo


        // Establece el tama�o inicial de la ventana
        setSize(800, 600);

        // Posiciona el label despu�s de que la ventana sea visible
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                int windowWidth = getContentPane().getWidth();
                int windowHeight = getContentPane().getHeight();
                
                panchoLabel.setBounds(
                    (windowWidth - 400) / 2,
                    (windowHeight - (-200)) / 2,
                    400, 
                    200
                );
            }
        });

        contentPane.setComponentZOrder(panchoLabel, 0);

        crearBotonesIngredientes();
        crearBotonEntregarPedido(); // Crear el bot�n para entregar el pedido

        int startX = 1000;
        int finalX = (screenSize.width - 1500) / 2;
        int y = -150;

        Timer timer = new Timer(16, new ActionListener() {
            int currentX = startX;
            boolean animacionEntradaCompletada = false;
            boolean segundoPersonajeTermino = false;

            @Override
            public void actionPerformed(ActionEvent e) {
                int step = 8;

                // Animación del primer personaje
                if (!primerPersonajeTermino) {
                    if (!animacionEntradaCompletada) {
                        currentX -= step;
                        if (currentX <= finalX) {
                            currentX = finalX;
                            animacionEntradaCompletada = true;
                            animacionCompletada = true;
                            iniciarAnimacionTexto();
                        }
                    }
                    else if (dialogmanager1_Acto2.getDialogoActual().equals("CLIENTA: Gracias maestro")) {
                        currentX -= step;
                        if (currentX <= -1500) {
                            primerPersonajeTermino = true;
                            lblNewLabel.setVisible(false);
                            // Reiniciar posición para el segundo personaje
                            currentX = startX;
                            animacionEntradaCompletada = false;
                            lblNewLabel2.setVisible(true);
                        }
                    }
                    lblNewLabel.setBounds(currentX, y, 1500, 1000);
                }
                // Animación del segundo personaje
                else if (!segundoPersonajeTermino) {
                    if (!animacionEntradaCompletada) {
                        currentX -= step;
                        if (currentX <= finalX) {
                            currentX = finalX;
                            animacionEntradaCompletada = true;
                        }
                    }
                    else if (dialogmanager1_Acto2.getDialogoActual().equals("HERNAN:  Bueno viejo perdoname")) {
                        currentX -= step;
                        if (currentX <= -1500) {
                            segundoPersonajeTermino = true;
                            lblNewLabel2.setVisible(false);
                            // Reiniciar posición para el tercer personaje
                            currentX = startX;
                            animacionEntradaCompletada = false;
                            lblNewLabel3.setVisible(true);
                        }
                    }
                    lblNewLabel2.setBounds(currentX, y, 1500, 1000);
                }
                // Animación del tercer personaje
                else {
                    if (!animacionEntradaCompletada) {
                        currentX -= step;
                        if (currentX <= finalX) {
                            currentX = finalX;
                            animacionEntradaCompletada = true;
                        }
                    }
                    else if (dialogmanager1_Acto2.getDialogoActual().equals("HERNAN:  Bueno viejo perdoname1")) {
                        currentX -= step;
                        if (currentX <= -1500) {
                            ((Timer) e.getSource()).stop();
                            Episodio3SI episodio3SI= new Episodio3SI(); 
                            dispose(); 
                            episodio3SI.setVisible(true);
                        }
                    }
                    lblNewLabel3.setBounds(currentX, y, 1500, 1000);
                }

                contentPane.revalidate();
                contentPane.repaint();
            }
        });


        setSize(screenSize);
        setLocationRelativeTo(null);
        setResizable(false);
        timer.start();
    }
    private void iniciarAnimacionTexto() {
        if (textTimer != null && textTimer.isRunning()) {
            textTimer.stop();
        }

        String textoCompleto = dialogmanager1_Acto2 .getDialogoActual();
        mostrandoTexto = true;

        textTimer = new Timer(50, new ActionListener() {
            int index = 0;
            StringBuilder textoActual = new StringBuilder();

            @Override
            public void actionPerformed(ActionEvent e) {
                if (index < textoCompleto.length()) {
                    textoActual.append(textoCompleto.charAt(index));
                    lblNewLabel_1.setText("<html>" + textoActual.toString().replaceAll("\n", "<br>") + "</html>");
                    index++;
                } else {
                    ((Timer) e.getSource()).stop();
                    mostrandoTexto = false;
                }
            }
        });

        textTimer.start();
    }

    private void crearBotonesIngredientes() {
        // Asegúrate de que `contentPane` esté configurado correctamente y que sea accesible aquí.
        contentPane.setLayout(null); // Desactiva el LayoutManager para poder usar `setBounds()`.

        String[] ingredientes = {"Pan", "Salchicha", "Mayonesa", "Ketchup", "Mostaza"};
        int tamanoBoton = (int)(getContentPane().getWidth() * 0.07);

        // Mapa de posiciones personalizadas de los botones
        Map<String, Point> posicionesPersonalizadas = new HashMap<>();
        posicionesPersonalizadas.put("Pan", new Point(1000, 670));
        posicionesPersonalizadas.put("Salchicha", new Point(250, 490));
        posicionesPersonalizadas.put("Mayonesa", new Point(150, 670));
        posicionesPersonalizadas.put("Ketchup", new Point(250, 670));
        posicionesPersonalizadas.put("Mostaza", new Point(350, 670));

        for (String ingrediente : ingredientes) {
            JButton boton;
            
            // Crea un botón sin icono ni fondo
            boton = new JButton();
            boton.setBorderPainted(true); // Sin borde
            boton.setContentAreaFilled(true); // Sin fondo
            boton.setFocusPainted(true); // Sin efecto al recibir el foco
            boton.setOpaque(true); // Sin opacidad, completamente transparente
            boton.setFocusable(true); // No permitir que el botón reciba el foco

            // Acción del botón
            boton.addActionListener(e -> agregarIngrediente(ingrediente));

            // Usa la posición personalizada si existe
            Point posicion = posicionesPersonalizadas.getOrDefault(ingrediente, new Point(0, 0));
            boton.setBounds(posicion.x, posicion.y, tamanoBoton, tamanoBoton);
            contentPane.add(boton);
            contentPane.setComponentZOrder(boton, 0); // Asegúrate de que el botón esté por encima del fondo
        }
    }


    private void agregarIngrediente(String ingrediente) {
        switch (ingrediente) {
            case "Pan":
                tienePan = !tienePan;
                break;
            case "Salchicha":
                tieneSalchicha = !tieneSalchicha;
                break;
            case "Mayonesa":
                tieneMayonesa = !tieneMayonesa;
                break;
            case "Ketchup":
                tieneKetchup = !tieneKetchup;
                break;
            case "Mostaza":
                tieneMostaza = !tieneMostaza;
                break;
        }
        actualizarImagenPancho();
    }

    private void actualizarImagenPancho() {
        String imagenRuta = "/imagenes/pancho_vacio.png";

        if (tienePan) {
            imagenRuta = "/imagenes/Pan.png";
        }
        if (tienePan && tieneSalchicha) {
            imagenRuta = "/imagenes/Pancho_Simple.png";
        }
        if (tienePan && tieneSalchicha && tieneMayonesa) {
            imagenRuta = "/imagenes/Pancho_Con_Mayo.png";
        }
        if (tienePan && tieneSalchicha && tieneKetchup) {
            imagenRuta = "/imagenes/Pancho_Con_Ketchup.png";
        }
        if (tienePan && tieneSalchicha && tieneMostaza) {
            imagenRuta = "/imagenes/Pancho_Con_Mostaza.png";
        }
        if (tienePan && tieneSalchicha && tieneMayonesa && tieneKetchup) {
            imagenRuta = "/imagenes/Pancho_Con_MayoYKetchup.png";
        }
        if (tienePan && tieneSalchicha && tieneMayonesa && tieneMostaza) {
            imagenRuta = "/imagenes/Pancho_Con_MayoYMostaza.png";
        }
        if (tienePan && tieneSalchicha && tieneMostaza && tieneKetchup) {
            imagenRuta = "/imagenes/Pancho_Con_MostazaYKetchup.png";
        }
        if (tienePan && tieneSalchicha && tieneMostaza && tieneKetchup && tieneMayonesa) {
            imagenRuta = "/imagenes/Pancho_Con_Todo.png";
        }

        panchoLabel.setIcon(escalarImagen(imagenRuta, 1600, 800));
    }

    private void crearBotonEntregarPedido() {
        btnEntregarPedido = new JButton();
        
        // Dimensiones del botón
        int btnWidth = 150;
        int btnHeight = 150;
        
        btnEntregarPedido.setBounds(600, 550, btnWidth, btnHeight);
        btnEntregarPedido.setBorder(null);
        btnEntregarPedido.setContentAreaFilled(false);
        btnEntregarPedido.setOpaque(false);
        
        // Cargar y optimizar la imagen
        ImageIcon iconoOriginal = new ImageIcon(Episodio1.class.getResource("/ingredientes/entregar.png"));
        Image imgOriginal = iconoOriginal.getImage();
        
        // Usar BufferedImage para mejor rendimiento
        BufferedImage resizedImg = new BufferedImage(btnWidth, btnHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = resizedImg.createGraphics();
        
        // Configurar la calidad del renderizado
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Dibujar la imagen escalada
        g2.drawImage(imgOriginal, 0, 0, btnWidth, btnHeight, null);
        g2.dispose();
        
        btnEntregarPedido.setIcon(new ImageIcon(resizedImg));
        btnEntregarPedido.setIconTextGap(0);
        
        btnEntregarPedido.addActionListener(e -> entregarPedido());
        
        contentPane.add(btnEntregarPedido);
        contentPane.setComponentZOrder(btnEntregarPedido, 0);
        
        // Fondo
        JLabel lblNewLabel_2 = new JLabel("New label");
        lblNewLabel_2.setIcon(new ImageIcon(Episodio1.class.getResource("/imagenes/fondoplaya.png")));
        lblNewLabel_2.setBounds(0, 0, 1920, 1080);
        contentPane.add(lblNewLabel_2);
    }
    
    private void entregarPedido() {
        int pedidoActual = dialogmanager1_Acto2.getPedidoActual();
        boolean pedidoCorrecto;
        
        switch (pedidoActual) {
            case 1:
                // Primer pedido: Pan, Salchicha y Ketchup
                pedidoCorrecto = tienePan && tieneSalchicha && !tieneKetchup && 
                                !tieneMayonesa && tieneMostaza;
                break;
            case 2:
                // Segundo pedido: Pan, Salchicha, Ketchup y Mostaza
                pedidoCorrecto = tienePan && tieneSalchicha && tieneKetchup && 
                                tieneMayonesa && tieneMostaza;
                break;
            case 3:
                // Tercer pedido: Pan, Salchicha, Ketchup, Mostaza y Mayonesa
                pedidoCorrecto = tienePan && tieneSalchicha && tieneKetchup && 
                                !tieneMayonesa && tieneMostaza;
                break;
            default:
                pedidoCorrecto = false;
                break;
        }

        // Obtener el diálogo según el pedido actual
        String dialogoPedido = dialogmanager1_Acto2.obtenerDialogoPedido(pedidoCorrecto);
        lblNewLabel_1.setText("<html>" + dialogoPedido.replaceAll("\n", "<br>") + "</html>");

        Timer timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (pedidoCorrecto) {
                    dialogmanager1_Acto2.reanudarDialogos(pedidoCorrecto);
                    panchoLabel.setVisible(false);
                    reiniciarIngredientes();
                    
                    if (pedidoActual <= 2) {  // Modificado para incluir el tercer pedido
                        dialogmanager1_Acto2.avanzarPedido();
                    }
                    
                    if (dialogmanager1_Acto2.siguienteDialogo()) {
                        iniciarAnimacionTexto();
                    }
                    panchoLabel.setVisible(true);
                }
            }
        });
        timer.setRepeats(false);
        timer.start();
    }

    // Método para reiniciar ingredientes
    private void reiniciarIngredientes() {
        tienePan = false;
        tieneSalchicha = false;
        tieneKetchup = false;
        tieneMayonesa = false;
        tieneMostaza = false;
        // Actualizar la interfaz gráfica si es necesario
        actualizarImagenPancho();
    }


    @Override
    public void keyPressed(KeyEvent e) {}
    @Override
    public void keyReleased(KeyEvent e) {}
    @Override
    public void keyTyped(KeyEvent e) {}
}
