public class DialogManager5 {
    private String[] dialogos;
    private int dialogoActual;
    private boolean debeAnimar = false;
    private boolean enPausa = false;
    private int pedidoActual = 1;

    public DialogManager5() {
        dialogos = new String[]{
            // Personaje 1: Horacio y Cliente 1
            "HORACIO: ¡Bienvenido! ¿Qué te traigo hoy?",
            "CLIENTE 1: Hola, ¿tienen pancho con salsa picante?",
            "HORACIO: Lo siento, no me queda salsa picante, ¿te va con mostaza?",
            "CLIENTE 1: Hmm, está bien, lo tomaré así.",
            
            // Personaje 2: Cliente 2
            "CLIENTE 2: ¿Este es el famoso puesto de panchos de Horacio?",
            "HORACIO: El único y original, ¿quieres probarlo?",
            "CLIENTE 2: Claro, dame uno con todo menos mayonesa.",
            "HORACIO: Ya viene.",
            
            // Personaje 3: Cliente 3
            "*Entra un personaje desconocido con sombrero*",
            "CLIENTE 3: Buenas, Horacio. Me dijeron que tienes el mejor pancho de la ciudad.",
            "HORACIO: Claro que sí, ¿cómo lo quieres?",
            "CLIENTE 3: Sorpéndeme.",
            
            // Personaje 4: Cliente 4
            "CLIENTE 4: ¡Hola Horacio! ¿Tienes algo especial hoy?",
            "HORACIO: ¡Sí! Hoy tenemos pancho con cebolla caramelizada, ¿te interesa?",
            "CLIENTE 4: Eso suena genial, dame uno.",
            "HORACIO: ¡Te va a encantar!",
            
            // Personaje 5: Cliente 5
            "CLIENTE 5: Buenas, ¿puedo pedir un pancho con todo y con mucho ketchup?",
            "HORACIO: Claro, va con mucho gusto.",
            "CLIENTE 5: ¡Perfecto, gracias!",
            "HORACIO: ¡Disfrutalo!",
            
            // Personaje 6: Cliente 6
            "CLIENTE 6: Hola, ¿tienen pancho con queso derretido?",
            "HORACIO: Sí, claro, ¿te gustaría con extra de queso?",
            "CLIENTE 6: ¡Sí, por favor!",
            "HORACIO: ¡Ya te lo traigo!",
            
            // Personaje 7: Cliente 7
            "CLIENTE 7: Buen día, quiero un pancho con todo pero sin cebolla."            
        };
        dialogoActual = 0;
    }

    // Métodos principales de navegación de diálogos
    public String getDialogoActual() {
        if (dialogoActual < dialogos.length) {
            return dialogos[dialogoActual];
        }
        return "";
    }

    public boolean siguienteDialogo() {
        if (enPausa) {
            return false;
        }
        if (dialogoActual < dialogos.length - 1) {
            dialogoActual++;
            
            // Verifica las pausas
            verificarPausaSegunPedido();
            
            // Verifica animación
            verificarAnimacion();

            return true;
        }
        return false;
    }

    // Métodos de control de animación
    private void verificarAnimacion() {
    	//PARA CUANDO SE VAN TAMBIEN
        String dialogo = dialogos[dialogoActual];
        debeAnimar = dialogo.equals("CLIENTE 2: ¿Este es el famoso puesto de panchos de Horacio?") ||
                     dialogo.equals("*Entra un personaje desconocido con sombrero*") || 
                     dialogo.equals("CLIENTE 4: ¡Hola Horacio! ¿Tienes algo especial hoy?") ||
                     dialogo.equals("CLIENTE 5: Buenas, ¿puedo pedir un pancho con todo y con mucho ketchup?") ||
                     dialogo.equals("CLIENTE 6: Hola, ¿tienen pancho con queso derretido?") || 
                     dialogo.equals("CLIENTE 7: Buen día, quiero un pancho con todo pero sin cebolla.") ;
    }

    private void verificarPausaSegunPedido() {
        switch(pedidoActual) {
        //DIALOGO CON PAUSA
            case 1: enPausa = (dialogoActual == 3); break;
            case 2: enPausa = (dialogoActual == 7); break;
            case 3: enPausa = (dialogoActual == 11); break;
            case 4: enPausa = (dialogoActual == 15); break;
            case 5: enPausa = (dialogoActual == 19); break;
            case 6: enPausa = (dialogoActual == 23); break;
            case 7: enPausa = (dialogoActual == 27); break;
            case 8: enPausa = (dialogoActual == 31); break;
            case 9: enPausa = (dialogoActual == 35); break;
        }
    }

    // Métodos de control de estado
    public String obtenerDialogoPedido(boolean pedidoCorrecto) {
        if (pedidoCorrecto) {
            return obtenerDialogoExitoso();
        } else {
            return obtenerDialogoFallido();
        }
    }

    private String obtenerDialogoExitoso() {
        switch(pedidoActual) {
            case 1: return "HORACIO: Aquí tienes tu pancho con ketchup, como me pediste.";
            case 2: return "HORACIO: Tu pancho con ketchup y mostaza, como pediste.";
            case 3: return "HORACIO: Acá tienes tu pancho con todo, como querías.";
            case 4: return "HORACIO: Aquí está tu pancho con todo lo que pediste.";
            case 5: return "HORACIO: Aquí tienes tu pancho con todo, sin problemas.";
            case 6: return "HORACIO: Pancho con todo y sin mayo, todo en orden.";           
            default: return "";
        }
    }

    private String obtenerDialogoFallido() {
        switch(pedidoActual) {
            case 1: return "CLIENTA: ¡ME QUERES MATAR! Soy alérgica a la mostaza y la mayonesa, solo ketchup!";
            case 2: return "HORACIO: (Em... creo que no es lo que me pidió, ¿qué había pedido realmente?)";
            case 3: return "HORACIO: (Este chico dijo con todo... ¿no?)";
            case 4: return "CLIENTE: Esto no es lo que pedí, ¡pero igual lo intentaré!";
            case 5: return "CLIENTE: ¡Esto no tiene ketchup! ¿Qué pasó?";
            case 6: return "CLIENTE: ¡Esto no está bien! ¡Mayo no! ¡Solo ketchup!";            
            default: return "";
        }
    }

    // Getters y setters
    public boolean debeAnimar() {
        return debeAnimar;
    }

    public void resetearAnimacion() {
        debeAnimar = false;
    }

    public int getPedidoActual() {
        return pedidoActual;
    }

    public void avanzarPedido() {
        pedidoActual++;
    }

    public boolean hayMasDialogos() {
        return dialogoActual < dialogos.length - 1;
    }

    public boolean estaEnPausa() {
        return enPausa;
    }

    public void setPausa(boolean pausa) {
        this.enPausa = pausa;
    }

    public int getIndiceDialogoActual() {
        return dialogoActual;
    }

    public void setIndiceDialogoActual(int indice) {
        if (indice >= 0 && indice < dialogos.length) {
            this.dialogoActual = indice;
        }
    }

    public int getCantidadDialogos() {
        return dialogos.length;
    }

    public boolean esUltimoDialogo() {
        return dialogoActual == dialogos.length - 1;
    }

    public String getDialogo(int indice) {
        if (indice >= 0 && indice < dialogos.length) {
            return dialogos[indice];
        }
        return "";
    }

    // Métodos de control de flujo
    public void reanudarDialogos(boolean pedidoCorrecto) {
        if (pedidoCorrecto) {
            enPausa = false;
        }
    }

    public void reiniciarDialogos() {
        dialogoActual = 0;
        pedidoActual = 1;
        debeAnimar = false;
        enPausa = false;
    }

    public boolean dialogoAnterior() {
        if (dialogoActual > 0) {
            dialogoActual--;
            return true;
        }
        return false;
    }
}