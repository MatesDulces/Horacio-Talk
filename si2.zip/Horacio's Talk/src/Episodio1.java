import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.Font;
import java.awt.Color;
import javax.swing.SwingConstants;

public class Episodio1 extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    private ImageIcon escalarImagen(String ruta, int ancho, int alto) {
        ImageIcon imagenOriginal = new ImageIcon(Episodio1.class.getResource(ruta));
        Image imagen = imagenOriginal.getImage();
        Image imagenEscalada = imagen.getScaledInstance(ancho, alto, Image.SCALE_SMOOTH);
        return new ImageIcon(imagenEscalada);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Episodio1 frame = new Episodio1();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    public Episodio1() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true); 
        
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.window);
        contentPane.setBorder(null);
        setContentPane(contentPane);

        contentPane.setPreferredSize(screenSize);
        contentPane.setSize(screenSize);
        contentPane.setLayout(null);


        int labelWidth = 1500;  
        int labelHeight = 1000; 

        JLabel lblNewLabel = new JLabel("");
        lblNewLabel.setBounds(1050, -100, 1451, 900);
        lblNewLabel.setIcon(escalarImagen("/imagenes/lachinacreoquefunciona.png", labelWidth, labelHeight));
        lblNewLabel.setForeground(SystemColor.infoText);
        lblNewLabel.setBackground(SystemColor.textText);

        contentPane.add(lblNewLabel);
     
        JLabel backgroundLabel = new JLabel("");   
        backgroundLabel.setBounds(-60, 0, screenSize.width, screenSize.height);
        backgroundLabel.setIcon(escalarImagen("/imagenes/fondo.png", screenSize.width, screenSize.height));
        contentPane.add(backgroundLabel);


        JLabel lblNewLabel_1 = new JLabel("");
        lblNewLabel_1.setBackground(SystemColor.text);
        lblNewLabel_1.setVerticalAlignment(SwingConstants.TOP);
        lblNewLabel_1.setForeground(SystemColor.textHighlight);
        lblNewLabel_1.setBounds(100, 30, 1950, 200);
        lblNewLabel_1.setFont(new Font("Cascadia Code", Font.BOLD, 40));
        contentPane.add(lblNewLabel_1);

        // Texto completo que se mostrará letra por letra
        String textoCompleto = "HORACIO: A Mi primera clienta \n*Horacio se pone atento para la posible venta*";



        // Reordenar los componentes para que el fondo esté atrás
        contentPane.setComponentZOrder(lblNewLabel, contentPane.getComponentCount() - 1);
        contentPane.setComponentZOrder(backgroundLabel, contentPane.getComponentCount() - 2);
        
        
        JLabel lblNewLabel_2 = new JLabel("");
        lblNewLabel_2.setBounds(0, 0, 1920, 1091);
        contentPane.add(lblNewLabel_2);

        // Animación de movimiento
        int startX = 1000;
        int finalX = (screenSize.width - labelWidth) / 2;
        int y = -150;

        Timer timer = new Timer(16, new ActionListener() {
            int currentX = startX;
            
            @Override
            public void actionPerformed(ActionEvent e) {
                int step = 6;
                currentX -= step;
                
                if (currentX <= finalX) {
                    currentX = finalX;
                    ((Timer)e.getSource()).stop();
                }
                
                lblNewLabel.setBounds(currentX, y, labelWidth, labelHeight);
                contentPane.revalidate();
                contentPane.repaint();
            }
        });

        // Timer para la animación del texto
        Timer textTimer = new Timer(50, new ActionListener() {
            int index = 0;
            StringBuilder textoActual = new StringBuilder();
            
            @Override
            public void actionPerformed(ActionEvent e) {
                if (index < textoCompleto.length()) {
                    textoActual.append(textoCompleto.charAt(index));
                    lblNewLabel_1.setText("<html>" + textoActual.toString().replaceAll("\n", "<br>") + "</html>");
                    index++;
                } else {
                    ((Timer) e.getSource()).stop();
                }
            }
        });

        setSize(screenSize);
        setLocationRelativeTo(null);
        setResizable(false);
        
        timer.start();
        textTimer.start(); // Iniciar la animación del texto
    }
}
