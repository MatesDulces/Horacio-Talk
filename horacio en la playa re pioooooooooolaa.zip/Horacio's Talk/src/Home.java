import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;

public class Home extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JButton startButton;
    private JButton episodio2;
    private JButton episodio3;
    private JButton episodio4;
    private JButton quitButton;
    private int selectedIndex = 0;
    private Timer blinkTimer;
    private boolean isBlinking = false;
    private JLabel leftEmoji;
    private JLabel rightEmoji;
    private ImageIcon backgroundImage;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Home frame = new Home();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Home() {
        // Configuración para pantalla completa
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Eliminar decoraciones de la ventana
        setUndecorated(true);
        
        // Establecer el tamaño a pantalla completa
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        GraphicsDevice gd = ge.getDefaultScreenDevice();
        
        if (gd.isFullScreenSupported()) {
            gd.setFullScreenWindow(this);
        } else {
            // Si no se soporta el modo pantalla completa, maximizar la ventana
            setExtendedState(JFrame.MAXIMIZED_BOTH);
        }

        // Crear el panel de contenido y ajustarlo a toda la pantalla
        contentPane = new JPanel() {
            private static final long serialVersionUID = 1L;

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Dibujar la imagen de fondo ajustada
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage.getImage(), 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null); // Usar un diseño absoluto
        setContentPane(contentPane);

        // Cargar la imagen de fondo
        backgroundImage = new ImageIcon(Home.class.getResource("/imagenes/PantallaInicioMejorado.png"));

        leftEmoji = new JLabel("-");
        leftEmoji.setForeground(Color.BLACK);
        rightEmoji = new JLabel("-");
        rightEmoji.setForeground(Color.BLACK);
        leftEmoji.setFont(new Font("Arial", Font.PLAIN, 30));
        rightEmoji.setFont(new Font("Arial", Font.PLAIN, 30));
        contentPane.add(leftEmoji);
        contentPane.add(rightEmoji);

        // Crear botones con posiciones relativas centradas
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        startButton = createButton("EPISODIO 1", 925, 525);
        episodio2 = createButton("EPISODIO 2", 1200, 525);
        episodio3 = createButton("EPISODIO 3", 925, 630);
        episodio4 = createButton("EPISODIO 4", 1200, 630);
        quitButton = createButton("SALIR", 1030, 800);

        // Agregar ActionListener a cada botón
        startButton.addActionListener(e -> startGame());
        episodio2.addActionListener(e -> episodio2());
        episodio3.addActionListener(e -> episodio3());
        episodio4.addActionListener(e -> episodio4());
        quitButton.addActionListener(e -> quitGame());

        contentPane.add(startButton);
        contentPane.add(episodio2);
        contentPane.add(episodio3);
        contentPane.add(episodio4);
        contentPane.add(quitButton);
       
        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(KeyEvent evt) {
                handleKeyPress(evt);
            }
        });

        setFocusable(true);
        requestFocusInWindow();
        updateButtonSelection();
    }

    private JButton createButton(String text, int x, int y) {
        JButton button = new JButton(text);
        button.setBounds(x, y, 200, 50); // Posiciona el botón con coordenadas absolutas
        button.setOpaque(true);
        button.setForeground(Color.BLACK);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setBackground(Color.BLACK);
        return button;
    }

    private void handleKeyPress(KeyEvent evt) {
        switch (evt.getKeyCode()) {
            case KeyEvent.VK_UP:
                selectedIndex = (selectedIndex > 0) ? selectedIndex - 1 : 4;
                updateButtonSelection();
                break;
            case KeyEvent.VK_DOWN:
                selectedIndex = (selectedIndex < 4) ? selectedIndex + 1 : 0;
                updateButtonSelection();
                break;
            case KeyEvent.VK_ENTER:
                executeSelectedOption();
                break;
            case KeyEvent.VK_ESCAPE:
                quitGame();
                break;
        }
    }

    private void executeSelectedOption() {
        switch (selectedIndex) {
            case 0:
                startGame();
                break;
            case 1:
                episodio2();
                break;
            case 2:
                episodio3();
                break;
            case 3:
                episodio4();
                break;
            case 4:
                quitGame();
                break;
        }
    }

    private void updateButtonSelection() {
        if (blinkTimer != null) {
            blinkTimer.stop();
        }

        JButton selectedButton = getSelectedButton();
        int buttonY = selectedButton.getY();
        leftEmoji.setBounds(selectedButton.getX() - 40, buttonY, 50, 50); // Ajustar la posición de los emojis
        rightEmoji.setBounds(selectedButton.getX() + 200, buttonY, 50, 50);

        blinkTimer = new Timer(400, e -> {
            if (isBlinking) {
                selectedButton.setForeground(Color.BLUE);
            } else {
                selectedButton.setForeground(Color.BLACK);
            }
            isBlinking = !isBlinking;
        });
        blinkTimer.start();

        // Restablecer colores de todos los botones
        startButton.setForeground(Color.BLACK);
        episodio2.setForeground(Color.BLACK);
        episodio3.setForeground(Color.BLACK);
        episodio4.setForeground(Color.BLACK);
        quitButton.setForeground(Color.BLACK);

        // Establecer color del botón seleccionado
        selectedButton.setForeground(Color.BLUE);

        repaint();
    }

    private JButton getSelectedButton() {
        switch (selectedIndex) {
            case 0: return startButton;
            case 1: return episodio2;
            case 2: return episodio3;
            case 3: return episodio4;
            case 4: return quitButton;
            default: return startButton;
        }
    }

    private void startGame() {
        EventQueue.invokeLater(() -> {
            Episodio1 episodio1 = new Episodio1();
            episodio1.setVisible(true);
            dispose();
        });
    }

    private void episodio2() {
        EventQueue.invokeLater(() -> {
            Episodio2 episodio2 = new Episodio2();
            episodio2.setVisible(true);
            dispose();
        });
    }

    private void episodio3() {
        EventQueue.invokeLater(() -> {
            Episodio3 episodio3 = new Episodio3();
            episodio3.setVisible(true);
            dispose();
        });
    }

    private void episodio4() {
        EventQueue.invokeLater(() -> {
            Episodio4 episodio4 = new Episodio4();
            episodio4.setVisible(true);
            dispose();
        });
    }

    private void quitGame() {
        System.exit(0);
    }
}