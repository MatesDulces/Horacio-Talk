
public class Episodio2 {

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}

}
