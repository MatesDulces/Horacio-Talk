public class DialogManager1_Acto2 {
    private String[] dialogos;
    private int dialogoActual;
    private boolean enPausa = false;
    // Agregar una variable para controlar si es momento de la animación de salida
    private boolean debeAnimar = false;

    public DialogManager1_Acto2() {
        // Agregar los diálogos básicos
        dialogos = new String[]{
            "HORACIO: Ah, mi primer cliente",
            "*Horacio se prepara para atender a la joven que llega*",
            "CLIENTA: Hola buen día, ¿te puedo pedir un pancho con ketchup?",
            "CLIENTA: Para preparar el pedido, selecciona los ingredientes en orden \ndesde el menú izquierdo.",
            "HORACIO: Como no, ya va",
            // Los diálogos relacionados con el pedido solo serán actualizados al presionar el botón
            "CLIENTA: Gracias muy amable"
        };
        dialogoActual = 0;
    }

    public String getDialogoActual() {
        if (dialogoActual < dialogos.length) {
            return dialogos[dialogoActual];
        }
        return "";
    }

    public boolean siguienteDialogo() {
        if (enPausa) {
            return false;
        }
        if (dialogoActual < dialogos.length - 1) {
            dialogoActual++;
            if (dialogoActual == 4) {
                enPausa = true;
            }
            if (dialogos[dialogoActual].equals("CLIENTA: Gracias muy amable")) {
                debeAnimar = true;
            }
            return true;
        }
        return false;
    }

    // Agregar método para verificar si debe animar
    public boolean debeAnimar() {
        return debeAnimar;
    }

    // Agregar método para resetear la animación
    public void resetearAnimacion() {
        debeAnimar = false;
    }

    // ... (mantener el resto de los métodos igual)

    public void reanudarDialogos(boolean pedidoCorrecto) {
        if (pedidoCorrecto) {
            enPausa = false;
        }
    }

    public boolean hayMasDialogos() {
        return dialogoActual < dialogos.length - 1;
    }

    public void reiniciarDialogos() {
        dialogoActual = 0;
        debeAnimar = false;
    }

    public String obtenerDialogoPedido(boolean pedidoCorrecto) {
        if (pedidoCorrecto) {
            return "HORACIO: ¡El pedido está listo! Aquí tienes tu pancho con ketchup.";
        } else {
            return "HORACIO: ¡El pedido no es correcto! Asegúrate de agregar\nlos ingredientes correctos.";
        }
    }
}