import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;

public class Home extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JButton startButton;
    private JButton episodio2;
    private JButton episodio3;
    private JButton episodio4;
    private JButton quitButton;
    private int selectedIndex = 0;
    private Timer blinkTimer;
    private boolean isBlinking = false;
    private JLabel leftEmoji;
    private JLabel rightEmoji;
    private JLabel lblNewLabel;
    private JLabel lblNewLabel_1;
    private JLabel lblNewLabel_2;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Home frame = new Home();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Home() {
        // Configuración para pantalla completa
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximiza la ventana
        setUndecorated(true); // Quita los bordes de la ventana

        // Crear el panel de contenido y ajustarlo a toda la pantalla
        contentPane = new JPanel();
        contentPane.setBackground(new Color(135, 206, 250));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null); // Usar un diseño absoluto para que podamos posicionar componentes libremente
        setContentPane(contentPane);
        
        // Ajustar el panel a las dimensiones de la pantalla
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        contentPane.setPreferredSize(screenSize);
        contentPane.setBounds(0, 0, screenSize.width, screenSize.height);

        leftEmoji = new JLabel("-");
        leftEmoji.setBackground(Color.BLUE);
        leftEmoji.setForeground(Color.BLUE);
        rightEmoji = new JLabel("-");
        rightEmoji.setBackground(Color.BLUE);
        rightEmoji.setForeground(Color.BLUE);
        leftEmoji.setFont(new Font("Arial", Font.PLAIN, 30));
        rightEmoji.setFont(new Font("Arial", Font.PLAIN, 30));
        contentPane.add(leftEmoji);
        contentPane.add(rightEmoji);

        // Crear botones con posiciones relativas centradas
        startButton = createButton("EPISODIO 1", screenSize.width / 2 - 100, 300);
        episodio2 = createButton("EPISODIO 2", screenSize.width / 2 - 100, 400);
        episodio3 = createButton("EPISODIO 3", screenSize.width / 2 - 100, 500);
        episodio4 = createButton("EPISODIO 4", screenSize.width / 2 - 100, 600);
        quitButton = createButton("SALIR", screenSize.width / 2 - 100, 700);

        // Agregar ActionListener a cada botón
        startButton.addActionListener(e -> startGame());
        episodio2.addActionListener(e -> episodio2());
        episodio3.addActionListener(e -> episodio3());
        episodio4.addActionListener(e -> episodio4());
        quitButton.addActionListener(e -> quitGame());

        contentPane.add(startButton);
        contentPane.add(episodio2);
        contentPane.add(episodio3);
        contentPane.add(episodio4);
        contentPane.add(quitButton);
       
        lblNewLabel = new JLabel("");
        lblNewLabel.setBounds(104, 22, 891, 104);
        contentPane.add(lblNewLabel);
        
        lblNewLabel_1 = new JLabel("");
        lblNewLabel_1.setBounds(0, 0, screenSize.width, screenSize.height);
        contentPane.add(lblNewLabel_1);
        
        lblNewLabel_2 = new JLabel("");
        lblNewLabel_2.setIcon(new ImageIcon(Home.class.getResource("/imagenes/horacio para la intro.png")));
        lblNewLabel_2.setBounds(0, 0, 154, 485);
        contentPane.add(lblNewLabel_2);

        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                handleKeyPress(evt);
            }
        });

        setFocusable(true);
        requestFocusInWindow();
        updateButtonSelection();
        pack();  // Ajusta el JFrame al tamaño preferido del contentPane
    }

    private JButton createButton(String text, int x, int y) {
        JButton button = new JButton(text);
        button.setBounds(x, y, 200, 50); // Posiciona el botón con coordenadas absolutas
        button.setOpaque(true);
        button.setForeground(Color.YELLOW);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setBackground(Color.BLUE);
        return button;
    }

    private void handleKeyPress(KeyEvent evt) {
        switch (evt.getKeyCode()) {
            case KeyEvent.VK_UP:
                selectedIndex = (selectedIndex > 0) ? selectedIndex - 1 : 4;
                updateButtonSelection();
                break;
            case KeyEvent.VK_DOWN:
                selectedIndex = (selectedIndex < 4) ? selectedIndex + 1 : 0;
                updateButtonSelection();
                break;
            case KeyEvent.VK_ENTER:
                executeSelectedOption();
                break;
        }
    }

    private void executeSelectedOption() {
        switch (selectedIndex) {
            case 0:
                startGame();
                break;
            case 1:
                episodio2();
                break;
            case 2:
                episodio3();
                break;
            case 3:
                episodio4();
                break;
            case 4:
                quitGame();
                break;
        }
    }

    private void updateButtonSelection() {
        if (blinkTimer != null) {
            blinkTimer.stop();
        }

        JButton selectedButton = getSelectedButton();
        int buttonY = selectedButton.getY();
        leftEmoji.setBounds(selectedButton.getX() - 40, buttonY, 50, 50); // Ajustar la posición de los emojis
        rightEmoji.setBounds(selectedButton.getX() + 200, buttonY, 50, 50);

        blinkTimer = new Timer(400, e -> {
            if (isBlinking) {
                selectedButton.setForeground(Color.BLUE);
            } else {
                selectedButton.setForeground(Color.YELLOW);
            }
            isBlinking = !isBlinking;
        });
        blinkTimer.start();

        // Restablecer colores de todos los botones
        startButton.setForeground(Color.YELLOW);
        episodio2.setForeground(Color.YELLOW);
        episodio3.setForeground(Color.YELLOW);
        episodio4.setForeground(Color.YELLOW);
        quitButton.setForeground(Color.YELLOW);

        // Establecer color del botón seleccionado
        selectedButton.setForeground(Color.BLUE);

        repaint();
    }

    private JButton getSelectedButton() {
        switch (selectedIndex) {
            case 0: return startButton;
            case 1: return episodio2;
            case 2: return episodio3;
            case 3: return episodio4;
            case 4: return quitButton;
            default: return startButton;
        }
    }

    private void startGame() {
        EventQueue.invokeLater(() -> {
            Episodio1 episodio1 = new Episodio1();
            episodio1.setVisible(true);
            dispose();
        });
    }

    private void episodio2() {
        EventQueue.invokeLater(() -> {
            Episodio2 episodio2 = new Episodio2();
            episodio2.setVisible(true);
            dispose();
        });
    }

    private void episodio3() {
        EventQueue.invokeLater(() -> {
            Episodio3 episodio3 = new Episodio3();
            episodio3.setVisible(true);
            dispose();
        });
    }

    private void episodio4() {
        EventQueue.invokeLater(() -> {
            Episodio4 episodio4 = new Episodio4();
            episodio4.setVisible(true);
            dispose();
        });
    }

    private void quitGame() {
        System.exit(0);
    }
}
