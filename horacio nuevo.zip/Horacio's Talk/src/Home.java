import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Home extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JButton startButton;
    private JButton episodio2;
    private JButton episodio3;
    private JButton episodio4;
    private JButton quitButton;
    private int selectedIndex = 0;
    private Timer blinkTimer;
    private boolean isBlinking = false;
    private JLabel leftEmoji;
    private JLabel rightEmoji;
    private JLabel lblNewLabel;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Home frame = new Home();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Home() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(170, 5, 1000, 700);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(135, 206, 250));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        leftEmoji = new JLabel("-");
        leftEmoji.setBackground(Color.BLUE);
        leftEmoji.setForeground(Color.BLUE);
        rightEmoji = new JLabel("-");
        rightEmoji.setBackground(Color.BLUE);
        rightEmoji.setForeground(Color.BLUE);
        leftEmoji.setFont(new Font("Arial", Font.PLAIN, 30));
        rightEmoji.setFont(new Font("Arial", Font.PLAIN, 30));
        contentPane.add(leftEmoji);
        contentPane.add(rightEmoji);

        // Crear botones con posiciones verticales diferentes
        startButton = createButton("EPISODIO 1", 400, 200);
        episodio2 = createButton("EPISODIO 2", 400, 270);
        episodio3 = createButton("EPISODIO 3", 400, 340);
        episodio4 = createButton("EPISODIO 4", 400, 410);
        quitButton = createButton("SALIR", 400, 500);

        // Agregar ActionListener a cada botón
        startButton.addActionListener(e -> startGame());
        episodio2.addActionListener(e -> episodio2());
        episodio3.addActionListener(e -> episodio3());
        episodio4.addActionListener(e -> episodio4());
        quitButton.addActionListener(e -> quitGame());

        contentPane.add(startButton);
        contentPane.add(episodio2);
        contentPane.add(episodio3);
        contentPane.add(episodio4);
        contentPane.add(quitButton);
       
        lblNewLabel = new JLabel("");
        lblNewLabel.setBounds(104, 22, 891, 104);
        contentPane.add(lblNewLabel);

        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                handleKeyPress(evt);
            }
        });

        setFocusable(true);
        requestFocusInWindow();
        updateButtonSelection();
    }

    private JButton createButton(String text, int x, int y) {
        JButton button = new JButton(text);
        button.setBounds(x, y, 200, 50);
        button.setOpaque(true);
        button.setForeground(Color.YELLOW);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setBackground(Color.BLUE);
        return button;
    }

    private void handleKeyPress(KeyEvent evt) {
        switch (evt.getKeyCode()) {
            case KeyEvent.VK_UP:
                selectedIndex = (selectedIndex > 0) ? selectedIndex - 1 : 4;
                updateButtonSelection();
                break;
            case KeyEvent.VK_DOWN:
                selectedIndex = (selectedIndex < 4) ? selectedIndex + 1 : 0;
                updateButtonSelection();
                break;
            case KeyEvent.VK_ENTER:
                executeSelectedOption();
                break;
        }
    }

    private void executeSelectedOption() {
        switch (selectedIndex) {
            case 0:
                startGame();
                break;
            case 1:
                episodio2();
                break;
            case 2:
                episodio3();
                break;
            case 3:
                episodio4();
                break;
            case 4:
                quitGame();
                break;
        }
    }

    private void updateButtonSelection() {
        if (blinkTimer != null) {
            blinkTimer.stop();
        }

        JButton selectedButton = getSelectedButton();
        int buttonY = selectedButton.getY();
        leftEmoji.setBounds(390, buttonY, 50, 50);
        rightEmoji.setBounds(600, buttonY, 50, 50);

        blinkTimer = new Timer(400, e -> {
            if (isBlinking) {
                selectedButton.setForeground(Color.BLUE);
            } else {
                selectedButton.setForeground(Color.YELLOW);
            }
            isBlinking = !isBlinking;
        });
        blinkTimer.start();

        // Restablecer colores de todos los botones
        startButton.setForeground(Color.YELLOW);
        episodio2.setForeground(Color.YELLOW);
        episodio3.setForeground(Color.YELLOW);
        episodio4.setForeground(Color.YELLOW);
        quitButton.setForeground(Color.YELLOW);

        // Establecer color del botón seleccionado
        selectedButton.setForeground(Color.BLUE);

        repaint();
    }

    private JButton getSelectedButton() {
        switch (selectedIndex) {
            case 0: return startButton;
            case 1: return episodio2;
            case 2: return episodio3;
            case 3: return episodio4;
            case 4: return quitButton;
            default: return startButton;
        }
    }

    private void startGame() {
        EventQueue.invokeLater(() -> {
            Episodio1 episodio1 = new Episodio1();
            episodio1.setVisible(true);
            dispose();
        });
    }

    private void episodio2() {
        EventQueue.invokeLater(() -> {
            Episodio2 episodio2 = new Episodio2();
            episodio2.setVisible(true);
            dispose();
        });
    }

    private void episodio3() {
        EventQueue.invokeLater(() -> {
            Episodio3 episodio3 = new Episodio3();
            episodio3.setVisible(true);
            dispose();
        });
    }

    private void episodio4() {
        EventQueue.invokeLater(() -> {
            Episodio4 episodio4 = new Episodio4();
            episodio4.setVisible(true);
            dispose();
        });
    }

    private void quitGame() {
        System.exit(0);
    }
}