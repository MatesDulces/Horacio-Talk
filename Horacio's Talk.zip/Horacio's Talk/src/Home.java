import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Home extends JFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
    private JButton startButton;
    private JButton quitButton;
    private int selectedIndex = 0;
    private Timer blinkTimer;
    private boolean isBlinking = false;
    private JLabel leftEmoji;
    private JLabel rightEmoji;
    private JLabel lblNewLabel;
    private JLabel lblNewLabel_1;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Home frame = new Home();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Home() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(170, 5, 1000, 700);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(135, 206, 250));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        leftEmoji = new JLabel("-");
        leftEmoji.setBackground(Color.BLUE);
        leftEmoji.setForeground(Color.BLUE);
        rightEmoji = new JLabel("-");
        rightEmoji.setBackground(Color.BLUE);
        rightEmoji.setForeground(Color.BLUE);
        leftEmoji.setFont(new Font("Arial", Font.PLAIN, 30));
        rightEmoji.setFont(new Font("Arial", Font.PLAIN, 30));
        contentPane.add(leftEmoji);
        contentPane.add(rightEmoji);

        startButton = createButton("EMPIEZA!", 400, 100);
        quitButton = createButton("SALIR", 400, 500);

        contentPane.add(startButton);
        contentPane.add(quitButton);
       
        lblNewLabel = new JLabel("");
        lblNewLabel.setBounds(104, 22, 891, 104);
        contentPane.add(lblNewLabel);
        
        lblNewLabel_1 = new JLabel("");
        lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\Alumno\\Downloads\\1.png"));
        lblNewLabel_1.setBounds(-49, 200, 1767, 252);
        contentPane.add(lblNewLabel_1);

        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                handleKeyPress(evt);
            }
        });

        setFocusable(true);
        requestFocusInWindow();
        updateButtonSelection();
    }

    private JButton createButton(String text, int x, int y) {
        JButton button = new JButton(text);
        button.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        	}
        });
        button.setBounds(x, y, 200, 50);
        button.setOpaque(true);
        button.setForeground(Color.YELLOW);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setBackground(Color.BLUE);
        return button;
    }

    private void handleKeyPress(KeyEvent evt) {
        switch (evt.getKeyCode()) {
            case KeyEvent.VK_UP:
            case KeyEvent.VK_DOWN:
                selectNextButton();
                break;
            case KeyEvent.VK_ENTER:
                if (selectedIndex == 0) {
                   startGame();
                } else {
                    quitGame();
                }
                break;
        }
    }

    private void selectNextButton() {
        selectedIndex = (selectedIndex == 0) ? 1 : 0;
        updateButtonSelection();
    }

    private void updateButtonSelection() {
        if (blinkTimer != null) {
            blinkTimer.stop();
        }

        JButton selectedButton = (selectedIndex == 0) ? startButton : quitButton;

        int buttonY = selectedButton.getY();
        leftEmoji.setBounds(390, buttonY, 50, 50);
        rightEmoji.setBounds(600, buttonY, 50, 50);

        blinkTimer = new Timer(400, e -> {
            if (isBlinking) {
                selectedButton.setForeground(Color.BLUE);
            } else {
                selectedButton.setForeground(Color.YELLOW);
            }
            isBlinking = !isBlinking;
        });
        blinkTimer.start();

        startButton.setForeground(selectedIndex == 0 ? Color.BLUE : Color.YELLOW);
        quitButton.setForeground(selectedIndex == 1 ? Color.BLUE : Color.YELLOW);

        repaint(); // Asegurarse de que los cambios se muestren inmediatamente
    }

   private void startGame() {
        EventQueue.invokeLater(() -> {
            Episodio1 Episodio1 = new Episodio1();
            Episodio1.setVisible(true);
            dispose();
        });
    }

    private void quitGame() {
        System.exit(0);
    }
}