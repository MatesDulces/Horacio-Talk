import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Episodio1 extends JFrame implements KeyListener {
    private static final long serialVersionUID = 1L;
    private JLayeredPane layeredPane;
    private JPanel contentPane;
    private JLabel lblNewLabel_1;
    private Timer textTimer;
    private DialogManager dialogManager;
    private boolean mostrandoTexto = false;
    private boolean animacionCompletada = false;
    private Panchos pancho;
    private JPanel ingredientesPanel;

/*    private static final String PREPARAR_PANCHO = "Preparar Pancho";
    private static final String AGREGAR_KETCHUP = "Agregar Ketchup";
    private static final String AGREGAR_MOSTAZA = "Agregar Mostaza";
    private static final String AGREGAR_CEBOLLA = "Agregar Cebolla";
    private static final String DESECHAR_PANCHO = "Desechar Pancho";
*/
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Episodio1 frame = new Episodio1();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Episodio1() {
        configurarVentana();
        inicializarComponentes();
        crearBotones();
        iniciarAnimacionEntrada();
    }

    private void configurarVentana() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true);
        addKeyListener(this);
        setFocusable(true);
        
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setSize(screenSize);
        setLocationRelativeTo(null);
        setResizable(false);
    }

    private void inicializarComponentes() {
        dialogManager = new DialogManager();
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

        // Inicializar JLayeredPane
        layeredPane = new JLayeredPane();
        layeredPane.setPreferredSize(screenSize);
        setContentPane(layeredPane);

        // Panel de fondo
        contentPane = new JPanel();
        contentPane.setOpaque(false);
        contentPane.setBounds(0, 0, screenSize.width, screenSize.height);
        contentPane.setLayout(null);
        layeredPane.add(contentPane, JLayeredPane.DEFAULT_LAYER);

        // Configurar elementos visuales
        configurarElementosVisuales(screenSize);
        
        // Configurar Panchos
        pancho = new Panchos();
        JLabel panchoLabel = pancho.getPanchoLabel();
        layeredPane.add(panchoLabel, JLayeredPane.POPUP_LAYER);

        // Inicializar panel de ingredientes
        ingredientesPanel = new JPanel();
        ingredientesPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 20, 10));
        ingredientesPanel.setOpaque(false);
        ingredientesPanel.setBounds(100, 1000, 1000, 80);
        layeredPane.add(ingredientesPanel, JLayeredPane.DRAG_LAYER);

        // Configurar eventos del mouse
        configurarEventosMouse();
    }

    private void configurarElementosVisuales(Dimension screenSize) {
        JLabel backgroundLabel = new JLabel();
        backgroundLabel.setBounds(0, 0, screenSize.width, screenSize.height);
        backgroundLabel.setIcon(escalarImagen("/imagenes/fondo.png", screenSize.width, screenSize.height));
        layeredPane.add(backgroundLabel, JLayeredPane.DEFAULT_LAYER);

        JLabel personajeLabel = new JLabel();
        personajeLabel.setBounds(1050, -100, 1451, 900);
        personajeLabel.setIcon(escalarImagen("/imagenes/lachinacreoquefunciona.png", 1500, 1000));
        layeredPane.add(personajeLabel, JLayeredPane.PALETTE_LAYER);

        lblNewLabel_1 = new JLabel("");
        lblNewLabel_1.setVerticalAlignment(SwingConstants.TOP);
        lblNewLabel_1.setForeground(SystemColor.textHighlight);
        lblNewLabel_1.setBounds(100, 30, 1950, 200);
        lblNewLabel_1.setFont(new Font("Cascadia Code", Font.BOLD, 40));
        layeredPane.add(lblNewLabel_1, JLayeredPane.DRAG_LAYER);
    }
    private void crearBoton(JPanel panel, String texto, Runnable accion) {
        JButton boton = new JButton(texto);
        boton.addActionListener(e -> accion.run());
        panel.add(boton);
    }


    private void configurarEventosMouse() {
        contentPane.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (!animacionCompletada) return;
                
                if (mostrandoTexto) {
                    completarTextoActual();
                } else {
                    avanzarSiguienteDialogo();
                }
            }
        });
    }

    private void crearBotones() {
        crearBoton(ingredientesPanel, "Preparar Pancho", () -> {
            if (!pancho.estaPreparado()) {
                pancho.prepararPancho();
                mostrarBotonesIngredientes();
            } else {
                ocultarBotonesIngredientes();
                pancho.resetearPancho();
            }
        });
    }

    private void mostrarBotonesIngredientes() {
        ingredientesPanel.removeAll(); // Limpia los botones existentes
        
        crearBoton(ingredientesPanel, "Preparar Pancho", () -> {
            if (!pancho.estaPreparado()) {
                pancho.prepararPancho();
                mostrarBotonesIngredientes();
            } else {
                ocultarBotonesIngredientes();
                pancho.resetearPancho();
            }
        });
        
        crearBoton(ingredientesPanel, "Agregar Ketchup", () -> pancho.agregarKetchup());
        crearBoton(ingredientesPanel, "Agregar Mostaza", () -> pancho.agregarMostaza());
        crearBoton(ingredientesPanel, "Agregar Cebolla", () -> pancho.agregarCebolla());
        crearBoton(ingredientesPanel, "Desechar Pancho", () -> {
            pancho.resetearPancho();
            ocultarBotonesIngredientes();
        });
        
        ingredientesPanel.revalidate();
        ingredientesPanel.repaint();
    }

    // Agregar este nuevo método
    private void ocultarBotonesIngredientes() {
        ingredientesPanel.removeAll();
        crearBoton(ingredientesPanel, "Preparar Pancho", () -> {
            if (!pancho.estaPreparado()) {
                pancho.prepararPancho();
                mostrarBotonesIngredientes();
            } else {
                ocultarBotonesIngredientes();
                pancho.resetearPancho();
            }
        });
        ingredientesPanel.revalidate();
        ingredientesPanel.repaint();
    }


    private ImageIcon escalarImagen(String ruta, int ancho, int alto) {
        ImageIcon imagenOriginal = new ImageIcon(getClass().getResource(ruta));
        Image imagen = imagenOriginal.getImage();
        Image imagenEscalada = imagen.getScaledInstance(ancho, alto, Image.SCALE_SMOOTH);
        return new ImageIcon(imagenEscalada);
    }

    private void iniciarAnimacionEntrada() {
        Timer timer = new Timer(16, new ActionListener() {
            int currentX = 1000;
            final int finalX = (getWidth() - 1500) / 2;
            
            @Override
            public void actionPerformed(ActionEvent e) {
                currentX -= 8;
                
                if (currentX <= finalX) {
                    currentX = finalX;
                    ((Timer)e.getSource()).stop();
                    animacionCompletada = true;
                    iniciarAnimacionTexto();
                }
                
                Component[] components = layeredPane.getComponentsInLayer(JLayeredPane.PALETTE_LAYER);
                if (components.length > 0) {
                    components[0].setBounds(currentX, -150, 1500, 1000);
                }
                layeredPane.repaint();
            }
        });
        timer.start();
    }

    private void iniciarAnimacionTexto() {
        if (textTimer != null && textTimer.isRunning()) {
            textTimer.stop();
        }

        String textoCompleto = dialogManager.getDialogoActual();
        mostrandoTexto = true;

        textTimer = new Timer(50, new ActionListener() {
            int index = 0;
            StringBuilder textoActual = new StringBuilder();
            
            @Override
            public void actionPerformed(ActionEvent e) {
                if (index < textoCompleto.length()) {
                    textoActual.append(textoCompleto.charAt(index));
                    lblNewLabel_1.setText("<html>" + textoActual.toString().replaceAll("\n", "<br>") + "</html>");
                    index++;
                } else {
                    ((Timer) e.getSource()).stop();
                    mostrandoTexto = false;
                }
            }
        });
        
        textTimer.start();
    }

    private void completarTextoActual() {
        textTimer.stop();
        lblNewLabel_1.setText("<html>" + dialogManager.getDialogoActual().replaceAll("\n", "<br>") + "</html>");
        mostrandoTexto = false;
    }

    private void avanzarSiguienteDialogo() {
        if (dialogManager.hayMasDialogos()) {
            dialogManager.siguienteDialogo();
            iniciarAnimacionTexto();
        }
    }

    private void avanzarDialogo() {
        if (!animacionCompletada) return;
        
        if (mostrandoTexto) {
            completarTextoActual();
        } else {
            avanzarSiguienteDialogo();
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_SPACE || e.getKeyCode() == KeyEvent.VK_ENTER) {
            avanzarDialogo();
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyReleased(KeyEvent e) {}
}
