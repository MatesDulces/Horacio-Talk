import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.awt.Image;

public class Panchos {
    private JLabel panchoLabel;
    private boolean estaPreparado;
    private boolean tieneKetchup;
    private boolean tieneMostaza;
    private boolean tieneCebolla;
    
    public Panchos() {
        estaPreparado = false;
        tieneKetchup = false;
        tieneMostaza = false;
        tieneCebolla = false;
        
        panchoLabel = new JLabel();
        panchoLabel.setBounds(300, 600, 300, 150);
        actualizarImagen();
    }
    
    public JLabel getPanchoLabel() {
        return panchoLabel;
    }
    
    private void actualizarImagen() {
        String rutaImagen = "/imagenes/pancho_base.png";
        if (estaPreparado) {
            if (tieneKetchup && tieneMostaza && tieneCebolla) {
                rutaImagen = "/imagenes/pancho_completo.png";
            } else if (tieneKetchup && tieneMostaza) {
                rutaImagen = "/imagenes/pancho_ketchup_mostaza.png";
            } else if (tieneKetchup) {
                rutaImagen = "/imagenes/pancho_ketchup.png";
            } else if (tieneMostaza) {
                rutaImagen = "/imagenes/pancho_mostaza.png";
            }
        }
        
        ImageIcon imagenOriginal = new ImageIcon(getClass().getResource(rutaImagen));
        Image imagen = imagenOriginal.getImage();
        Image imagenEscalada = imagen.getScaledInstance(400, 400, Image.SCALE_SMOOTH);
        panchoLabel.setIcon(new ImageIcon(imagenEscalada));
    }
    
    public void prepararPancho() {
        estaPreparado = true;
        actualizarImagen();
    }
    
    public void agregarKetchup() {
        if (estaPreparado) {
            tieneKetchup = true;
            actualizarImagen();
        }
    }
    
    public void agregarMostaza() {
        if (estaPreparado) {
            tieneMostaza = true;
            actualizarImagen();
        }
    }
    
    public void agregarCebolla() {
        if (estaPreparado) {
            tieneCebolla = true;
            actualizarImagen();
        }
    }
    
    public boolean estaCompleto() {
        return estaPreparado && tieneKetchup && tieneMostaza && tieneCebolla;
    }
    public void resetearPancho() {
        estaPreparado = false;
        tieneKetchup = false;
        tieneMostaza = false;
        tieneCebolla = false;
        actualizarImagen();
    }
    public boolean estaPreparado() {
        return estaPreparado;
    }
}
