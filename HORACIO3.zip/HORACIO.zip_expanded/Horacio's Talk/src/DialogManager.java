public class DialogManager {
    private String[] dialogos;
    private int dialogoActual;

    public DialogManager() {
        dialogos = new String[]{
            "HORACIO: A Mi primera clienta\n*Horacio se pone atento para la posible venta*",
            "CLIENTA: Buenos días, ¿tiene pasteles frescos?",
            "HORACIO: ¡Por supuesto! Recién horneados esta mañana",
            // Más diálogos aquí...
        };
        dialogoActual = 0;
    }

    public String getDialogoActual() {
        if (dialogoActual >= 0 && dialogoActual < dialogos.length) {
            return dialogos[dialogoActual];
        }
        return "";
    }

    public boolean siguienteDialogo() {
        if (dialogoActual < dialogos.length - 1) {
            dialogoActual++;
            return true;
        }
        return false;
    }

    public boolean hayMasDialogos() {
        return dialogoActual < dialogos.length - 1;
    }

    public void reiniciarDialogos() {
        dialogoActual = 0;
    }
}