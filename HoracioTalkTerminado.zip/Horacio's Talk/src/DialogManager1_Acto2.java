public class DialogManager1_Acto2 {
    private String[] dialogos;
    private int dialogoActual;
    private boolean debeAnimar = false;
    private boolean enPausa = false;
    private int pedidoActual = 1;

    public DialogManager1_Acto2() {
        dialogos = new String[]{
        		"*Ha pasado un tiempo, el negocio de Horacio prospera \ny tiene mucho trabajo.",
        		"HORACIO: Hoola, ¿Que se le ofrece?",
        		"CLIENTE 1: Hola, ¿Me da un pancho con mostaza y mayonesa?",
        		"CLIENTE 1: Aunque de hecho, no quiero ponerle mayonesa.",
        		"HORACIO: Ya mismo.",


        		"CLIENTE 1: Gracias.",
        		"HORACIO: SIGUIENTE.",
        		"CLIENTE 2: Hola Horacio, ¿Como va todo?",
        		"HORACIO: El negocio va bien, ¿Que vas a pedir?.",
        		"CLIENTE 2: Dame lo usual, un pancho con todo.",
        		
        		"HORACIO: (Cada vez viene gente mas rara...)",
        		"CLIENTE 3: Hola.",
        		"HORACIO: ¿Hola?",
        		"HORACIO: (Justo cuando crei que no podia ponerse \npeor..)",
        		"HORACIO: ¿Que se le ofrece?",
        		"CLIENTE 3: Quiero un pancho con todo, como \nera preparado en mi pueblo natal.",
        		"HORACIO: (¿¿¿En su pueblo natal??? Quien es este tipo...)",
        		"CLIENTE 3: Aunque de hecho, prefiero que lo prepares al \nestilo hakamiri.",
        		"HORACIO: Y como seria eso...",
        		"CLIENTE 3: Pancho con la sangre del enemigo y su toque agridulce.",

        		"HORACIO: (Espero que sea esto..)",
        		"ESPADACHIN: ¿AH, justo como lo recordaba! ¿Gracias Horacio!",
        		"HORACIO: Por nada...",
        		"HORACIO: Uff, ese fue el ultimo, que dia complicado... creo",

        };
        dialogoActual = 0;
    }


    // Obtiene el diálogo actual
    public String getDialogoActual() {
        if (dialogoActual < dialogos.length) {
            return dialogos[dialogoActual];
        }
        return "";
    }

    // Avanza al siguiente diálogo
    public boolean siguienteDialogo() {
        if (enPausa) {
            return false;
        }
        if (dialogoActual < dialogos.length - 1) {
            dialogoActual++;
            // Activa la pausa según el pedido actual
            if (pedidoActual == 1 && dialogoActual == 4) {
                enPausa = true;
            } else if (pedidoActual == 2 && dialogoActual == 9) {
                enPausa = true;
            } else if (pedidoActual == 3 && dialogoActual == 22) { // Nueva pausa para el tercer pedido
                enPausa = true;
            }
            // Activa la animación en momentos específicos
            if (dialogos[dialogoActual].equals("CLIENTA: Gracias maestro") ||
                dialogos[dialogoActual].equals("CLIENTE  Emm me llamo Hernan")) {
                debeAnimar = true;
            }
            return true;
        }
        return false;
    }

    // Verifica si debe animar
    public boolean debeAnimar() {
        return debeAnimar;
    }

    // Resetea la animación
    public void resetearAnimacion() {
        debeAnimar = false;
    }

    // Obtiene el pedido actual
    public int getPedidoActual() {
        return pedidoActual;
    }

    // Avanza al siguiente pedido
    public void avanzarPedido() {
        pedidoActual++;
    }

    // Reanuda los diálogos si el pedido es correcto
    public void reanudarDialogos(boolean pedidoCorrecto) {
        if (pedidoCorrecto) {
            enPausa = false;
        }
    }

    // Verifica si hay más diálogos
    public boolean hayMasDialogos() {
        return dialogoActual < dialogos.length - 1;
    }

    // Reinicia todos los diálogos
    public void reiniciarDialogos() {
        dialogoActual = 0;
        pedidoActual = 1;
        debeAnimar = false;
        enPausa = false;
    }

    // Obtiene el diálogo correspondiente según el estado del pedido
    public String obtenerDialogoPedido(boolean pedidoCorrecto) {
        switch(pedidoActual) {
            case 1:
                if (pedidoCorrecto) {
                    return "HORACIO: Listo el pancho.";
                } else {
                    return "CLIENTE 1: Esto no es lo que pedi.";
                }
            case 2:
                if (pedidoCorrecto) {
                    return "CLIENTE 2: GUAU! ESO ESTUVO DELICIOSO HERMANO!!";
                } else {
                    return "CLIENTE 2: HERMANO NO ERA TAN COMPLICADO CORRIGELO!";
                }
            case 3:
                if (pedidoCorrecto) {
                    return "HORACIO: Acá tenés tu pancho.";
                } else {
                    return "HORACIO: (Este chico dijo con todo... ¿no?)";
                }
            default:
                return "";
        }
    }

    // Verifica si el diálogo está en pausa
    public boolean estaEnPausa() {
        return enPausa;
    }

    // Establece el estado de pausa
    public void setPausa(boolean pausa) {
        this.enPausa = pausa;
    }

    // Obtiene el índice del diálogo actual
    public int getIndiceDialogoActual() {
        return dialogoActual;
    }

    // Establece el índice del diálogo actual
    public void setIndiceDialogoActual(int indice) {
        if (indice >= 0 && indice < dialogos.length) {
            this.dialogoActual = indice;
        }
    }

    // Obtiene la cantidad total de diálogos
    public int getCantidadDialogos() {
        return dialogos.length;
    }

    // Verifica si es el último diálogo
    public boolean esUltimoDialogo() {
        return dialogoActual == dialogos.length - 1;
    }

    // Obtiene el diálogo por índice
    public String getDialogo(int indice) {
        if (indice >= 0 && indice < dialogos.length) {
            return dialogos[indice];
        }
        return "";
    }

    // Retrocede al diálogo anterior
    public boolean dialogoAnterior() {
        if (dialogoActual > 0) {
            dialogoActual--;
            return true;
        }
        return false;
    }
}