import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;

import javax.swing.*;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
//presentacion de panchos inicio del sueño
public class Episodio1 extends JFrame implements KeyListener {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JLabel lblNewLabel_1;
    private Timer textTimer;
    private DialogManager dialogManager;
    private boolean mostrandoTexto = false;
    private boolean animacionCompletada = false;
    private JLabel panchoLabel; 
    private boolean tienePan = false;
    private boolean tieneSalchicha = false;
    private boolean tieneMayonesa = false;
    private boolean tieneKetchup = false;
    private boolean tieneMostaza = false;
    private JButton btnEntregarPedido; 
    
    private ImageIcon escalarImagen(String ruta, int ancho, int alto) {
        URL imgUrl = Episodio1.class.getResource(ruta);
        ImageIcon imagenOriginal = new ImageIcon(imgUrl);
        Image imagen = imagenOriginal.getImage();
        Image imagenEscalada = imagen.getScaledInstance(ancho, alto, Image.SCALE_SMOOTH);
        return new ImageIcon(imagenEscalada);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Episodio1 frame = new Episodio1();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Episodio1() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true);
        addKeyListener(this);
        setFocusable(true);

        dialogManager = new DialogManager();

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.window);
        contentPane.setBorder(null);
        setContentPane(contentPane);
        contentPane.setPreferredSize(screenSize);
        contentPane.setSize(screenSize);
        contentPane.setLayout(null);

        contentPane.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (!animacionCompletada) return;

                if (mostrandoTexto) {
                    textTimer.stop();
                    lblNewLabel_1.setText("<html>" + dialogManager.getDialogoActual().replaceAll("\n", "<br>") + "</html>");
                    mostrandoTexto = false;
                } else {
                    if (dialogManager.hayMasDialogos()) {
                        dialogManager.siguienteDialogo();
                        iniciarAnimacionTexto();
                    }
                }
            }
        });

        JLabel lblNewLabel = new JLabel("");
        lblNewLabel.setBounds(1050, -100, 1451, 900);
        lblNewLabel.setIcon(escalarImagen("/imagenes/lachinacreoquefunciona.png", 1500, 1000));
        contentPane.add(lblNewLabel);

        JLabel backgroundLabel = new JLabel("");
        backgroundLabel.setBounds(0, 0, screenSize.width, screenSize.height);
        backgroundLabel.setIcon(escalarImagen("/imagenes/CarritoConSalchicha.png", screenSize.width, screenSize.height));
        contentPane.add(backgroundLabel);

        lblNewLabel_1 = new JLabel("");
        lblNewLabel_1.setBackground(SystemColor.text);
        lblNewLabel_1.setVerticalAlignment(SwingConstants.TOP);
        lblNewLabel_1.setForeground(SystemColor.textHighlight);
        lblNewLabel_1.setBounds(100, 30, 1950, 200);
        lblNewLabel_1.setFont(new Font("Cascadia Code", Font.BOLD, 40));
        contentPane.add(lblNewLabel_1);

        contentPane.setComponentZOrder(lblNewLabel, contentPane.getComponentCount() - 1);
        contentPane.setComponentZOrder(backgroundLabel, contentPane.getComponentCount() - 2);

        panchoLabel = new JLabel(escalarImagen("/imagenes/pancho_vacio.png", 400, 200));
        contentPane.add(panchoLabel);

        setSize(800, 600);

        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                int windowWidth = getContentPane().getWidth();
                int windowHeight = getContentPane().getHeight();
                
                panchoLabel.setBounds(
                    (windowWidth - 400) / 2,
                    (windowHeight - (-200)) / 2,
                    400, 
                    200
                );
            }
        });

        contentPane.setComponentZOrder(panchoLabel, 0);

        crearBotonesIngredientes();
        crearBotonEntregarPedido(); 

        int startX = 1000;
        int finalX = (screenSize.width - 1500) / 2;
        int y = -150;

        Timer timer = new Timer(16, new ActionListener() {
            int currentX = startX;
            boolean animacionEntradaCompletada = false;

            public void actionPerformed(ActionEvent e) {
                int step = 8;
                
                if (!animacionEntradaCompletada) {
                    currentX -= step;  
                    if (currentX <= finalX) {
                        currentX = finalX;
                        animacionEntradaCompletada = true;
                        animacionCompletada = true;
                        iniciarAnimacionTexto();
                    }
                }
                else if (dialogManager.getDialogoActual().equals("HORACIO: (Fiestas?), Ok.... Suerte.") && animacionEntradaCompletada) {
                    currentX -= step;  
                    if (currentX <= -1500) {  
                        ((Timer) e.getSource()).stop();
                        Episodio1_Acto2 episodio1_acto2 = new Episodio1_Acto2(); 
                        dispose(); 
                        episodio1_acto2.setVisible(true);
                        

                    }
                }
                lblNewLabel.setBounds(currentX, y, 1500, 1000);
                contentPane.revalidate();
                contentPane.repaint();
            }
        });

        setSize(screenSize);
        setLocationRelativeTo(null);
        setResizable(false);

        timer.start();
    }
    private void iniciarAnimacionTexto() {
        if (textTimer != null && textTimer.isRunning()) {
            textTimer.stop();
        }

        String textoCompleto = dialogManager.getDialogoActual();
        mostrandoTexto = true;

        textTimer = new Timer(50, new ActionListener() {
            int index = 0;
            StringBuilder textoActual = new StringBuilder();

            @Override
            public void actionPerformed(ActionEvent e) {
                if (index < textoCompleto.length()) {
                    textoActual.append(textoCompleto.charAt(index));
                    lblNewLabel_1.setText("<html>" + textoActual.toString().replaceAll("\n", "<br>") + "</html>");
                    index++;
                } else {
                    ((Timer) e.getSource()).stop();
                    mostrandoTexto = false;
                }
            }
        });

        textTimer.start();
    }

    private void crearBotonesIngredientes() {
        contentPane.setLayout(null); // Desactiva el LayoutManager para poder usar `setBounds()`.

        String[] ingredientes = {"Pan", "Salchicha", "Mayonesa", "Ketchup", "Mostaza"};
        int tamanoBoton = (int)(getContentPane().getWidth() * 0.07);

        // Mapa de posiciones personalizadas de los botones
        Map<String, Point> posicionesPersonalizadas = new HashMap<>();
        posicionesPersonalizadas.put("Pan", new Point(1000, 670));
        posicionesPersonalizadas.put("Salchicha", new Point(250, 490));
        posicionesPersonalizadas.put("Mayonesa", new Point(150, 670));
        posicionesPersonalizadas.put("Ketchup", new Point(250, 670));
        posicionesPersonalizadas.put("Mostaza", new Point(350, 670));

        for (String ingrediente : ingredientes) {
            JButton boton;
            
            // Crea un botón sin icono ni fondo
            boton = new JButton();
            boton.setBorderPainted(false); // Sin borde
            boton.setContentAreaFilled(false); // Sin fondo
            boton.setFocusPainted(false); // Sin efecto al recibir el foco
            boton.setOpaque(false); // Sin opacidad, completamente transparente
            boton.setFocusable(false); // No permitir que el botón reciba el foco

            // Acción del botón
            boton.addActionListener(e -> agregarIngrediente(ingrediente));

            // Usa la posición personalizada si existe
            Point posicion = posicionesPersonalizadas.getOrDefault(ingrediente, new Point(0, 0));
            boton.setBounds(posicion.x, posicion.y, tamanoBoton, tamanoBoton);
            contentPane.add(boton);
            contentPane.setComponentZOrder(boton, 0); // Asegúrate de que el botón esté por encima del fondo
        }
    }



    private void agregarIngrediente(String ingrediente) {
        switch (ingrediente) {
            case "Pan":
                tienePan = !tienePan;
                break;
            case "Salchicha":
                tieneSalchicha = !tieneSalchicha;
                break;
            case "Mayonesa":
                tieneMayonesa = !tieneMayonesa;
                break;
            case "Ketchup":
                tieneKetchup = !tieneKetchup;
                break;
            case "Mostaza":
                tieneMostaza = !tieneMostaza;
                break;
        }
        actualizarImagenPancho();
    }

    private void actualizarImagenPancho() {
        String imagenRuta = "/imagenes/pancho_vacio.png";

        if (tienePan) {
            imagenRuta = "/imagenes/Pan.png";
        }
        if (tienePan && tieneSalchicha) {
            imagenRuta = "/imagenes/Pancho_Simple.png";
        }
        if (tienePan && tieneSalchicha && tieneMayonesa) {
            imagenRuta = "/imagenes/Pancho_Con_Mayo.png";
        }
        if (tienePan && tieneSalchicha && tieneKetchup) {
            imagenRuta = "/imagenes/Pancho_Con_Ketchup.png";
        }
        if (tienePan && tieneSalchicha && tieneMostaza) {
            imagenRuta = "/imagenes/Pancho_Con_Mostaza.png";
        }
        if (tienePan && tieneSalchicha && tieneMayonesa && tieneKetchup) {
            imagenRuta = "/imagenes/Pancho_Con_MayoYKetchup.png";
        }
        if (tienePan && tieneSalchicha && tieneMayonesa && tieneMostaza) {
            imagenRuta = "/imagenes/Pancho_Con_MayoYMostaza.png";
        }
        if (tienePan && tieneSalchicha && tieneMostaza && tieneKetchup) {
            imagenRuta = "/imagenes/Pancho_Con_MostazaYKetchup.png";
        }
        if (tienePan && tieneSalchicha && tieneMostaza && tieneKetchup && tieneMayonesa) {
            imagenRuta = "/imagenes/Pancho_Con_Todo.png";
        }

        panchoLabel.setIcon(escalarImagen(imagenRuta, 1600, 800));
    }

    private void crearBotonEntregarPedido() {
        btnEntregarPedido = new JButton();
        
        // Dimensiones del botón
        int btnWidth = 150;
        int btnHeight = 150;
        
        btnEntregarPedido.setBounds(600, 550, btnWidth, btnHeight);
        btnEntregarPedido.setBorder(null);
        btnEntregarPedido.setContentAreaFilled(false);
        btnEntregarPedido.setOpaque(false);
        
        // Cargar y optimizar la imagen
        ImageIcon iconoOriginal = new ImageIcon(Episodio1.class.getResource("/ingredientes/entregar.png"));
        Image imgOriginal = iconoOriginal.getImage();
        
        // Usar BufferedImage para mejor rendimiento
        BufferedImage resizedImg = new BufferedImage(btnWidth, btnHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = resizedImg.createGraphics();
        
        // Configurar la calidad del renderizado
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Dibujar la imagen escalada
        g2.drawImage(imgOriginal, 0, 0, btnWidth, btnHeight, null);
        g2.dispose();
        
        btnEntregarPedido.setIcon(new ImageIcon(resizedImg));
        btnEntregarPedido.setIconTextGap(0);
        
        btnEntregarPedido.addActionListener(e -> entregarPedido());
        
        contentPane.add(btnEntregarPedido);
        contentPane.setComponentZOrder(btnEntregarPedido, 0);
        
        // Fondo
        JLabel lblNewLabel_2 = new JLabel("New label");
        lblNewLabel_2.setIcon(new ImageIcon(Episodio1.class.getResource("/imagenes/fondoplaya.png")));
        lblNewLabel_2.setBounds(0, 0, 1920, 1080);
        contentPane.add(lblNewLabel_2);
    }


    private void entregarPedido() {
        final boolean pedidoCorrecto = tienePan && tieneKetchup && tieneSalchicha && !tieneMayonesa && !tieneMostaza;

        String dialogoPedido = dialogManager.obtenerDialogoPedido(pedidoCorrecto);

        lblNewLabel_1.setText("<html>" + dialogoPedido.replaceAll("\n", "<br>") + "</html>");

        Timer timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (pedidoCorrecto) {
                    dialogManager.reanudarDialogos(pedidoCorrecto); // Reanudar di�logos
                    panchoLabel.setVisible(false);
                    if (dialogManager.siguienteDialogo()) {
                        iniciarAnimacionTexto();
                    }
                } else {
                }
            }
        });
        timer.setRepeats(false);
        timer.start();
    }





    @Override
    public void keyPressed(KeyEvent e) {}
    @Override
    public void keyReleased(KeyEvent e) {}
    @Override
    public void keyTyped(KeyEvent e) {}
}
