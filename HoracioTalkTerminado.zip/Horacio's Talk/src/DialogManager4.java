public class DialogManager4 {
    private String[] dialogos;
    private int dialogoActual;
    private boolean debeAnimar = false;
    private boolean enPausa = false;
    private int pedidoActual = 1;

    public DialogManager4() {
        dialogos = new String[]{
            // Personaje 1: Horacio y Cliente 1
            "HORACIO: ¡Bienvenido! ¿Qué te traigo hoy?",
            "CLIENTE 1: Que onda Horacio todos estan apurados hoy \nvas a tener que apurarte",
            "HORACIO: Ou, bueno si tardo mucho pueden pasar y esperar su pedido",
            "CLIENTE 1: Esa es la actitud!, dame un pachito con mayo",
            
            // Personaje 2: Cliente 2
            "CLIENTE 2: Hola señor, ya tengo que entrar al trabajo",
            "CLIENTE 2: Deme una bondiola con Chimi",
            
            
            // Personaje 3: Cliente 3
            "SILLY BILLI: OU YEAH SILLY BILLI JOB",
            "SILLY BILLI: PANCHO WITH MAYONEISA",
            "HORACIO: (La pu..)",
            
            // Personaje 4: Cliente 4
            "CLIENTE 4: Bondiola sola",
            "HORACIO: Ok...",
            
            // Personaje 5: Cliente 5
            "CLIENTE 5: Bondiola suave sin tanto sabor a condimento",
            "HORACIO: ...",
            
            
            // Personaje 6: Cliente 6
            "CLIENTE 6: Superaste el dia Horacio, \nahora preparate para el siguiente...",
            "HORACIO: ...",           
            
            // Personaje 7: Cliente 7
            "HORACIO: (dios que dia atareado...)"            
        };
        dialogoActual = 0;
    }

    // Métodos principales de navegación de diálogos
    public String getDialogoActual() {
        if (dialogoActual < dialogos.length) {
            return dialogos[dialogoActual];
        }
        return "";
    }

    public boolean siguienteDialogo() {
        if (enPausa) {
            return false;
        }
        if (dialogoActual < dialogos.length - 1) {
            dialogoActual++;
            
            // Verifica las pausas
            verificarPausaSegunPedido();
            
            // Verifica animación
            verificarAnimacion();

            return true;
        }
        return false;
    }

    // Métodos de control de animación
    private void verificarAnimacion() {
    	//PARA CUANDO SE VAN TAMBIEN
        String dialogo = dialogos[dialogoActual];
        debeAnimar = dialogo.equals("CLIENTE 2: Hola señor, ya tengo que entrar al trabajo") ||
                     dialogo.equals("SILLY BILLI: OU YEAH SILLY BILLI JOB") || 
                     dialogo.equals("CLIENTE 4: Bondiola sola") ||
                     dialogo.equals("CLIENTE 5: Bondiola suave sin tanto sabor a condimento") ||
                     dialogo.equals("CLIENTE 6: Superaste el dia Horacio, \nahora preparate para el siguiente...") || 
                     dialogo.equals("CLIENTE 6: Superaste el dia Horacio, \nahora preparate para el siguiente...") ;
    }

    private void verificarPausaSegunPedido() {
        switch(pedidoActual) {
        //DIALOGO CON PAUSA
            case 1: enPausa = (dialogoActual == 3); break;
            case 2: enPausa = (dialogoActual == 5); break;
            case 3: enPausa = (dialogoActual == 8); break;
            case 4: enPausa = (dialogoActual == 10); break;
            case 5: enPausa = (dialogoActual == 12); break;
            case 6: enPausa = (dialogoActual == 14); break;    
        }
    }

    // Métodos de control de estado
    public String obtenerDialogoPedido(boolean pedidoCorrecto) {
        if (pedidoCorrecto) {
            return obtenerDialogoExitoso();
        } else {
            return obtenerDialogoFallido();
        }
    }

    private String obtenerDialogoExitoso() {
        switch(pedidoActual) {
            case 1: return "HORACIO: Aquí tienes.";
            case 2: return "HORACIO: Todo tuyo.";
            case 3: return "HORACIO: CHAU.";
            case 4: return "HORACIO: Aquí está.";
            case 5: return "HORACIO: Aquí tienes.";
            case 6: return "HORACIO: Con todo lo que haz pedido.";           
            default: return "";
        }
    }

    private String obtenerDialogoFallido() {
        switch(pedidoActual) {
            case 1: return "CLIENTA: Espero que no hagas todos los pedidos asi hoy...\n no vas a sobrevivir...";
            case 2: return "HORACIO: (Em... creo que no es lo que me pidió, ¿qué había pedido realmente?)";
            case 3: return "HORACIO: (Este que dijo...)";
            case 4: return "CLIENTE: Esto no es lo que pedí.";
            case 5: return "CLIENTE: ¡Esto no!";
            case 6: return "CLIENTE: ¡Esto no está bien!";            
            default: return "";
        }
    }

    // Getters y setters
    public boolean debeAnimar() {
        return debeAnimar;
    }

    public void resetearAnimacion() {
        debeAnimar = false;
    }

    public int getPedidoActual() {
        return pedidoActual;
    }

    public void avanzarPedido() {
        pedidoActual++;
    }

    public boolean hayMasDialogos() {
        return dialogoActual < dialogos.length - 1;
    }

    public boolean estaEnPausa() {
        return enPausa;
    }

    public void setPausa(boolean pausa) {
        this.enPausa = pausa;
    }

    public int getIndiceDialogoActual() {
        return dialogoActual;
    }

    public void setIndiceDialogoActual(int indice) {
        if (indice >= 0 && indice < dialogos.length) {
            this.dialogoActual = indice;
        }
    }

    public int getCantidadDialogos() {
        return dialogos.length;
    }

    public boolean esUltimoDialogo() {
        return dialogoActual == dialogos.length - 1;
    }

    public String getDialogo(int indice) {
        if (indice >= 0 && indice < dialogos.length) {
            return dialogos[indice];
        }
        return "";
    }

    // Métodos de control de flujo
    public void reanudarDialogos(boolean pedidoCorrecto) {
        if (pedidoCorrecto) {
            enPausa = false;
        }
    }

    public void reiniciarDialogos() {
        dialogoActual = 0;
        pedidoActual = 1;
        debeAnimar = false;
        enPausa = false;
    }

    public boolean dialogoAnterior() {
        if (dialogoActual > 0) {
            dialogoActual--;
            return true;
        }
        return false;
    }
}