import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;

import javax.swing.*;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
//aparece bondiola
public class Episodio3SI extends JFrame implements KeyListener {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JLabel lblNewLabel_1;
    private Timer textTimer;
    private DialogManager3 dialogmanager3;
    private boolean mostrandoTexto = false;
    private boolean animacionCompletada = false;
    private JLabel panchoLabel; // JLabel para mostrar el pancho
    private boolean tienePan = false;
    private boolean tieneSalchicha = false;
    private boolean tieneMayonesa = false;
    private boolean tieneKetchup = false;
    private boolean tieneMostaza = false;
    private boolean tieneChimichurri = false;
    private boolean tieneCriolla = false;
    private boolean tienePanB = false;
    private boolean tieneBondiola = false;
    private JButton btnEntregarPedido; // Bot�n para entregar el pedido
    private JLabel lblNewLabel; // Para NPC1
    private JLabel lblNewLabel2; // Para Thiago
    private JLabel lblNewLabel3; // Para Thiago

    private boolean primerPersonajeTermino = false;
    
    private ImageIcon escalarImagen(String ruta, int ancho, int alto) {
        URL imgUrl = Episodio1_Acto2.class.getResource(ruta);
        if (imgUrl == null) {
            System.err.println("Error: La imagen no se pudo encontrar en la ruta: " + ruta);
            return null; // o puedes retornar una imagen por defecto aqu�
        }
        ImageIcon imagenOriginal = new ImageIcon(imgUrl);
        Image imagen = imagenOriginal.getImage();
        Image imagenEscalada = imagen.getScaledInstance(ancho, alto, Image.SCALE_SMOOTH);
        return new ImageIcon(imagenEscalada);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Episodio1_Acto2 frame = new Episodio1_Acto2();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Episodio3SI() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setUndecorated(true);
        addKeyListener(this);
        setFocusable(true);

        dialogmanager3 = new DialogManager3();

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.window);
        contentPane.setBorder(null);
        setContentPane(contentPane);
        contentPane.setPreferredSize(screenSize);
        contentPane.setSize(screenSize);
        contentPane.setLayout(null);

        contentPane.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (!animacionCompletada) return;

                if (mostrandoTexto) {
                    textTimer.stop();
                    lblNewLabel_1.setText("<html>" + dialogmanager3 .getDialogoActual().replaceAll("\n", "<br>") + "</html>");
                    mostrandoTexto = false;
                } else {
                    if (dialogmanager3 .hayMasDialogos()) {
                    	dialogmanager3 .siguienteDialogo();
                        iniciarAnimacionTexto();
                    }
                }
            }
        });
     // Labels de personajes (al fondo)
        lblNewLabel3 = new JLabel("");
        lblNewLabel3.setBounds(1050, -100, 1451, 900);
        lblNewLabel3.setIcon(escalarImagen("/PERSONAJES/Billy.png", 1500, 1000));
        lblNewLabel3.setVisible(false);
        contentPane.add(lblNewLabel3);
        
        lblNewLabel2 = new JLabel("");
        lblNewLabel2.setBounds(1050, -100, 1451, 900);
        lblNewLabel2.setIcon(escalarImagen("/PERSONAJES/Marge.png", 1500, 1000));
        lblNewLabel2.setVisible(false);
        contentPane.add(lblNewLabel2);

        lblNewLabel = new JLabel("");
        lblNewLabel.setBounds(1050, -100, 1451, 900);
        lblNewLabel.setIcon(escalarImagen("/PERSONAJES/Billy.png", 1500, 1000));
        contentPane.add(lblNewLabel);
     // Background del carrito
        JLabel backgroundLabel = new JLabel("");
        backgroundLabel.setBounds(0, 0, screenSize.width, screenSize.height);
        backgroundLabel.setIcon(escalarImagen("/ingredientes/CarritoBondiola.png", screenSize.width, screenSize.height));
        contentPane.add(backgroundLabel);

        // Label del texto
        lblNewLabel_1 = new JLabel("");
        lblNewLabel_1.setBackground(SystemColor.text);
        lblNewLabel_1.setVerticalAlignment(SwingConstants.TOP);
        lblNewLabel_1.setForeground(SystemColor.textHighlight);
        lblNewLabel_1.setBounds(100, 30, 1950, 200);
        lblNewLabel_1.setFont(new Font("Cascadia Code", Font.BOLD, 40));
        contentPane.add(lblNewLabel_1);

        // Pancho (al frente de todo)
        panchoLabel = new JLabel(escalarImagen("/imagenes/pancho_vacio.png", 400, 200));
        contentPane.add(panchoLabel);

        // Establecer el orden explícitamente (0 es el frente, números mayores al fondo)
        contentPane.setComponentZOrder(panchoLabel, 0);          // Panchos al frente
        contentPane.setComponentZOrder(lblNewLabel_1, 1);        // Texto después
        contentPane.setComponentZOrder(backgroundLabel, 2);      // Carrito después
        contentPane.setComponentZOrder(lblNewLabel, 3);          // NPC1 al fondo
        contentPane.setComponentZOrder(lblNewLabel2, 3);         // Thiago al fondo
        contentPane.setComponentZOrder(lblNewLabel3, 3);         // Thiago al fondo


        // Establece el tama�o inicial de la ventana
        setSize(800, 600);

        // Posiciona el label despu�s de que la ventana sea visible
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                int windowWidth = getContentPane().getWidth();
                int windowHeight = getContentPane().getHeight();
                
                panchoLabel.setBounds(
                    (windowWidth - 400) / 2,
                    (windowHeight - (-200)) / 2,
                    400, 
                    200
                );
            }
        });

        contentPane.setComponentZOrder(panchoLabel, 0);

        crearBotonesIngredientes();
        crearBotonEntregarPedido(); // Crear el bot�n para entregar el pedido

        int startX = 1000;
        int finalX = (screenSize.width - 1500) / 2;
        int y = -150;

        Timer timer = new Timer(16, new ActionListener() {
            int currentX = startX;
            boolean animacionEntradaCompletada = false;
            boolean segundoPersonajeTermino = false;

            @Override
            public void actionPerformed(ActionEvent e) {
                int step = 8;

                // Animación del primer personaje
                if (!primerPersonajeTermino) {
                    if (!animacionEntradaCompletada) {
                        currentX -= step;
                        if (currentX <= finalX) {
                            currentX = finalX;
                            animacionEntradaCompletada = true;
                            animacionCompletada = true;
                            iniciarAnimacionTexto();
                        }
                    }
                    else if (dialogmanager3.getDialogoActual().equals("SILLY BILLY: ¡GRACIAS HERMANO HASTA LUEGO!")) {
                        currentX -= step;
                        if (currentX <= -1500) {
                            primerPersonajeTermino = true;
                            lblNewLabel.setVisible(false);
                            // Reiniciar posición para el segundo personaje
                            currentX = startX;
                            animacionEntradaCompletada = false;
                            lblNewLabel2.setVisible(true);
                        }
                    }
                    lblNewLabel.setBounds(currentX, y, 1500, 1000);
                }
                // Animación del segundo personaje
                else if (!segundoPersonajeTermino) {
                    if (!animacionEntradaCompletada) {
                        currentX -= step;
                        if (currentX <= finalX) {
                            currentX = finalX;
                            animacionEntradaCompletada = true;
                        }
                    }
                    else if (dialogmanager3.getDialogoActual().equals("HORACIO: Dios, que encuentro inesperado, \nme alegro el dia")) {
                        currentX -= step;
                        if (currentX <= -1500) {
                            segundoPersonajeTermino = true;
                            lblNewLabel2.setVisible(false);
                            // Reiniciar posición para el tercer personaje
                            currentX = startX;
                            animacionEntradaCompletada = false;
                            lblNewLabel3.setVisible(true);
                        }
                    }
                    lblNewLabel2.setBounds(currentX, y, 1500, 1000);
                }
                // Animación del tercer personaje
                else {
                    if (!animacionEntradaCompletada) {
                        currentX -= step;
                        if (currentX <= finalX) {
                            currentX = finalX;
                            animacionEntradaCompletada = true;
                        }
                    }
                    else if (dialogmanager3.getDialogoActual().equals("HORACIO: Ya por suerte es hora de terminar el dia.")) {
                        currentX -= step;
                        if (currentX <= -1500) {
                            ((Timer) e.getSource()).stop();
                            Episodio4 episodio4= new Episodio4(); 
                            dispose(); 
                            episodio4.setVisible(true);
                        }
                    }
                    lblNewLabel3.setBounds(currentX, y, 1500, 1000);
                }

                contentPane.revalidate();
                contentPane.repaint();
            }
        });


        setSize(screenSize);
        setLocationRelativeTo(null);
        setResizable(false);
        timer.start();
    }
    private void iniciarAnimacionTexto() {
        if (textTimer != null && textTimer.isRunning()) {
            textTimer.stop();
        }

        String textoCompleto = dialogmanager3 .getDialogoActual();
        mostrandoTexto = true;

        textTimer = new Timer(50, new ActionListener() {
            int index = 0;
            StringBuilder textoActual = new StringBuilder();

            @Override
            public void actionPerformed(ActionEvent e) {
                if (index < textoCompleto.length()) {
                    textoActual.append(textoCompleto.charAt(index));
                    lblNewLabel_1.setText("<html>" + textoActual.toString().replaceAll("\n", "<br>") + "</html>");
                    index++;
                } else {
                    ((Timer) e.getSource()).stop();
                    mostrandoTexto = false;
                }
            }
        });

        textTimer.start();
    }

    private void crearBotonesIngredientes() {
        // Asegúrate de que `contentPane` esté configurado correctamente y que sea accesible aquí.
        contentPane.setLayout(null); // Desactiva el LayoutManager para poder usar `setBounds()`.

        String[] ingredientes = {"Pan", "Salchicha", "Mayonesa", "Ketchup", "Mostaza", "Chimichurri", "Criolla", "PanB", "Bondiola"};
        int tamanoBoton = (int)(getContentPane().getWidth() * 0.07);

        // Mapa de posiciones personalizadas de los botones
        Map<String, Point> posicionesPersonalizadas = new HashMap<>();
        posicionesPersonalizadas.put("Pan", new Point(1000, 650));
        posicionesPersonalizadas.put("Salchicha", new Point(280, 450));
        posicionesPersonalizadas.put("Mayonesa", new Point(150, 670));
        posicionesPersonalizadas.put("Ketchup", new Point(250, 670));
        posicionesPersonalizadas.put("Chimichurri", new Point(350, 500));
        posicionesPersonalizadas.put("Criolla", new Point(200, 500));
        posicionesPersonalizadas.put("PanB", new Point(800, 650));
        posicionesPersonalizadas.put("Bondiola", new Point(450, 450));
        posicionesPersonalizadas.put("Mostaza", new Point(350, 670));

        // Mapa de colores para los botones
        /*Map<String, Color> coloresPersonalizados = new HashMap<>();
        coloresPersonalizados.put("Pan", new Color(210, 180, 140));      // Marrón claro
        coloresPersonalizados.put("Salchicha", new Color(139, 69, 19));  // Marrón oscuro
        coloresPersonalizados.put("Mayonesa", new Color(255, 255, 224)); // Blanco crema
        coloresPersonalizados.put("Ketchup", new Color(178, 34, 34));    // Rojo
        coloresPersonalizados.put("Mostaza", new Color(255, 215, 0));    // Amarillo
        coloresPersonalizados.put("Chimichurri", new Color(34, 139, 34)); // Verde
        coloresPersonalizados.put("Criolla", new Color(255, 140, 0));    // Naranja
        coloresPersonalizados.put("PanB", new Color(210, 180, 140));     // Marrón claro
        coloresPersonalizados.put("Bondiola", new Color(139, 69, 19));   // Marrón oscuro
*/
        for (String ingrediente : ingredientes) {
        	JButton boton = new JButton("");  // Botón sin texto
        	
            // Configuración visual del botón
            boton.setBorderPainted(false); // Sin borde
            boton.setContentAreaFilled(false); // Sin fondo
            boton.setFocusPainted(false); // Sin efecto al recibir el foco
            boton.setOpaque(false); // Sin opacidad, completamente transparente
            boton.setFocusable(false); // No permitir que el botón reciba el foco
            
            // Configuración del color
         //   Color colorBoton = coloresPersonalizados.getOrDefault(ingrediente, new Color(200, 200, 200));
           // boton.setBackground(colorBoton);
            //boton.setForeground(Color.BLACK);          // Color del texto
            
            // Estilo del botón
            //boton.setBorder(BorderFactory.createRaisedBevelBorder());
            //boton.setFont(new Font("Arial", Font.BOLD, 12));
            
            // Acción del botón
            boton.addActionListener(e -> agregarIngrediente(ingrediente));

            // Usa la posición personalizada si existe
            Point posicion = posicionesPersonalizadas.getOrDefault(ingrediente, new Point(0, 0));
            boton.setBounds(posicion.x, posicion.y, tamanoBoton, tamanoBoton);
            
            // Agregar tooltip
            boton.setToolTipText("Click para agregar/quitar " + ingrediente);

            contentPane.add(boton);
            contentPane.setComponentZOrder(boton, 0);
        }
    }





    private void agregarIngrediente(String ingrediente) {
        // Al agregar Pan de Bondiola, desactivamos el Pan normal y viceversa
        if (ingrediente.equals("PanB")) {
            tienePanB = !tienePanB;
            if (tienePanB) {
                tienePan = false;  // Si activamos PanB, desactivamos Pan
            }
        } else if (ingrediente.equals("Pan")) {
            tienePan = !tienePan;
            if (tienePan) {
                tienePanB = false;  // Si activamos Pan, desactivamos PanB
            }
        } else {
            // Para el resto de ingredientes, mantenemos la lógica original
            switch (ingrediente) {
                case "Salchicha":
                    tieneSalchicha = !tieneSalchicha;
                    break;
                case "Bondiola":
                    tieneBondiola = !tieneBondiola;
                    break;
                case "Mayonesa":
                    tieneMayonesa = !tieneMayonesa;
                    break;
                case "Ketchup":
                    tieneKetchup = !tieneKetchup;
                    break;
                case "Mostaza":
                    tieneMostaza = !tieneMostaza;
                    break;
                case "Chimichurri":
                    tieneChimichurri = !tieneChimichurri;
                    break;
                case "Criolla":
                    tieneCriolla = !tieneCriolla;
                    break;
            }
        }
        actualizarImagenPancho();
    }

    private void actualizarImagenPancho() {
        String imagenRuta = "/imagenes/pancho_vacio.png";
        
        // Separamos la lógica del pancho y la bondiola completamente
        if (tienePanB) {
            if (!tieneBondiola) {
                imagenRuta = "/imagenes/PanBondiola.png";
            } else {
                // Si tiene bondiola, verificamos las combinaciones
                imagenRuta = "/imagenes/BondiolaSimple1.png";
                
                // Verificamos las salsas individuales
                if (tieneChimichurri) {
                    imagenRuta = "/imagenes/BondiolaConChimi.png";
                }
                if (tieneCriolla) {
                    imagenRuta = "/imagenes/BondiolaConCriolla.png";
                }
                if (tieneMayonesa) {
                    imagenRuta = "/imagenes/BondiolaConMayo.png";
                }
                if (tieneKetchup) {
                    imagenRuta = "/imagenes/BondiolaConKetchup1.png";
                }
                if (tieneMostaza) {
                    imagenRuta = "/imagenes/BondiolaConMostaza.png";
                }
                if (tieneMayonesa && tieneKetchup) {
                    imagenRuta = "/imagenes/BondiolaConKetchupYMayonesa.png";
                }
                if (tieneMayonesa && tieneMostaza) {
                    imagenRuta = "/imagenes/BondiolaConMayonesaYMostaza.png";
                }
                if (tieneMostaza && tieneKetchup) {
                    imagenRuta = "/imagenes/BondiolaConKetchupYMostaza.png";
                }
                
                // Verificamos las combinaciones especiales
                if (tieneMayonesa && tieneKetchup && tieneMostaza) {
                    imagenRuta = "/imagenes/BondiolaConTodo1.png";
                }
                // Verificamos las combinaciones especiales
                if (tieneChimichurri && tieneCriolla) {
                    imagenRuta = "/imagenes/BondiolaConChimiYCriolla.png";
                }
            }
        }
        
        else if (tienePan) {  // Si no es bondiola, verificamos si es pancho
            imagenRuta = "/imagenes/Pan.png";
            
            if (tieneSalchicha) {
                imagenRuta = "/imagenes/Pancho_Simple.png";
                
                if (tieneMayonesa) {
                    imagenRuta = "/imagenes/Pancho_Con_Mayo.png";
                }
                if (tieneKetchup) {
                    imagenRuta = "/imagenes/Pancho_Con_Ketchup.png";
                }
                if (tieneMostaza) {
                    imagenRuta = "/imagenes/Pancho_Con_Mostaza.png";
                }
                if (tieneMayonesa && tieneKetchup) {
                    imagenRuta = "/imagenes/Pancho_Con_MayoYKetchup.png";
                }
                if (tieneMayonesa && tieneMostaza) {
                    imagenRuta = "/imagenes/Pancho_Con_MayoYMostaza.png";
                }
                if (tieneMostaza && tieneKetchup) {
                    imagenRuta = "/imagenes/Pancho_Con_MostazaYKetchup.png";
                }
                if (tieneMostaza && tieneKetchup && tieneMayonesa) {
                    imagenRuta = "/imagenes/Pancho_Con_Todo.png";
                }
            }
        }
        panchoLabel.setIcon(escalarImagen(imagenRuta, 1600, 800));
        
    }
       
           
    private void crearBotonEntregarPedido() {
        btnEntregarPedido = new JButton();
        
        // Dimensiones del botón
        int btnWidth = 150;
        int btnHeight = 150;
        
        btnEntregarPedido.setBounds(600, 550, btnWidth, btnHeight);
        btnEntregarPedido.setBorder(null);
        btnEntregarPedido.setContentAreaFilled(false);
        btnEntregarPedido.setOpaque(false);
        
        // Cargar y optimizar la imagen
        ImageIcon iconoOriginal = new ImageIcon(Episodio1.class.getResource("/ingredientes/entregar.png"));
        Image imgOriginal = iconoOriginal.getImage();
        
        // Usar BufferedImage para mejor rendimiento
        BufferedImage resizedImg = new BufferedImage(btnWidth, btnHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = resizedImg.createGraphics();
        
        // Configurar la calidad del renderizado
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Dibujar la imagen escalada
        g2.drawImage(imgOriginal, 0, 0, btnWidth, btnHeight, null);
        g2.dispose();
        
        btnEntregarPedido.setIcon(new ImageIcon(resizedImg));
        btnEntregarPedido.setIconTextGap(0);
        
        btnEntregarPedido.addActionListener(e -> entregarPedido());
        
        contentPane.add(btnEntregarPedido);
        contentPane.setComponentZOrder(btnEntregarPedido, 0);
        
        // Fondo
        JLabel lblNewLabel_2 = new JLabel("New label");
        lblNewLabel_2.setIcon(new ImageIcon(Episodio1.class.getResource("/imagenes/fondoplaya.png")));
        lblNewLabel_2.setBounds(0, 0, 1920, 1080);
        contentPane.add(lblNewLabel_2);
    }
    
    private void entregarPedido() {
        int pedidoActual = dialogmanager3.getPedidoActual();
        boolean pedidoCorrecto;
        
        switch (pedidoActual) {
            case 1:
                // Primer pedido: Pan, Salchicha y Ketchup
                pedidoCorrecto = tienePanB && tieneBondiola && tieneCriolla;
                break;
            case 2:
                // Segundo pedido: Pan, Salchicha, Ketchup y Mostaza
                pedidoCorrecto = tienePanB && tieneBondiola && tieneMayonesa && tieneKetchup ;
                break;
            case 3:
                // Tercer pedido: Pan, Salchicha, Ketchup y Mostaza
                pedidoCorrecto = tienePanB && tieneBondiola && tieneCriolla;
                break;
                     
            default:
                pedidoCorrecto = false;
                break;
        }

        // Obtener el diálogo según el pedido actual
        String dialogoPedido = dialogmanager3.obtenerDialogoPedido(pedidoCorrecto);
        lblNewLabel_1.setText("<html>" + dialogoPedido.replaceAll("\n", "<br>") + "</html>");

        Timer timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (pedidoCorrecto) {
                    dialogmanager3.reanudarDialogos(pedidoCorrecto);
                    panchoLabel.setVisible(false);
                    reiniciarIngredientes();
                    
                    if (pedidoActual <= 4) {  // Modificado para incluir hasta el quinto pedido
                        dialogmanager3.avanzarPedido();
                    }
                    
                    if (dialogmanager3.siguienteDialogo()) {
                        iniciarAnimacionTexto();
                    }
                    panchoLabel.setVisible(true);
                }
            }
        });
        timer.setRepeats(false);
        timer.start();
    }

    // Método para reiniciar ingredientes
    private void reiniciarIngredientes() {
        tienePan = false;
        tieneSalchicha = false;
        tieneKetchup = false;
        tieneMayonesa = false;
        tieneMostaza = false;
        tienePanB = false;
        tieneChimichurri = false;
        tieneCriolla = false;
        tieneBondiola = false;
        // Actualizar la interfaz gráfica si es necesario
        actualizarImagenPancho();
    }



    @Override
    public void keyPressed(KeyEvent e) {}
    @Override
    public void keyReleased(KeyEvent e) {}
    @Override
    public void keyTyped(KeyEvent e) {}
}
