public class DialogManager5 {
    private String[] dialogos;
    private int dialogoActual;
    private boolean debeAnimar = false;
    private boolean enPausa = false;
    private int pedidoActual = 1;

    public DialogManager5() {
        dialogos = new String[]{
            // Personaje 1: Horacio y Cliente 1
            "CLIENTE 1: Hoy estamos mas impacientes... \nSolo tendras 10segundos de nuestro tiempo",
            "CLIENTE 1: Dame pancho con mostaza, \nmayonesa y ketchup no",
            "HORACIO: ...ok",          
            
            // Personaje 2: Cliente 2
            "CLIENTE 2: Yo quiero bondiola con Chimi y Criolla",
            "HORACIO: ok",
                   
           
            "CLIENTE 3: Quiero un pancho con todo pero \nsin chimi y criolla que assssco.",
            "HORACIO: si",
                        
            // Personaje 4: Cliente 4
            "CLIENTE 4: Pan de pancho solo",
            "HORACIO: ...",
            
            // Personaje 5: Cliente 5
            "CLIENTE 5: Yo quiero pam de bondiolla con shimi\nosea sin crrrioia entei?",
            "HORACIO: Claro...",
            
            
            // Personaje 6: Cliente 6
            "CLIENTE 6: Superaste el dia Horacio, pero en verdad \n¿fue un dia comun y corriente?",
            "HORACIO: QUE ESTO.. ESTO ES UN SUEÑO!!!!",           
            
            // Personaje 7: Cliente 7
            "CLIENTE 6: Puedes decidir si quedarte con nostros\n o volver al mundo real...",
            "HORACIO: Si en el mundo real no existe\n el tonto Billy mejor..."
        };
        dialogoActual = 0;
    }

    // Métodos principales de navegación de diálogos
    public String getDialogoActual() {
        if (dialogoActual < dialogos.length) {
            return dialogos[dialogoActual];
        }
        return "";
    }

    public boolean siguienteDialogo() {
        if (enPausa) {
            return false;
        }
        if (dialogoActual < dialogos.length - 1) {
            dialogoActual++;
            
            // Verifica las pausas
            verificarPausaSegunPedido();
            
            // Verifica animación
            verificarAnimacion();

            return true;
        }
        return false;
    }

    // Métodos de control de animación
    private void verificarAnimacion() {
    	//PARA CUANDO SE VAN TAMBIEN
        String dialogo = dialogos[dialogoActual];
        debeAnimar = dialogo.equals("CLIENTE 2: Yo quiero bondiola con Chimi y Criolla") ||
                     dialogo.equals("CLIENTE 3: Quiero un pancho con todo pero \nsin chimi y criolla que assssco.") || 
                     dialogo.equals("CLIENTE 4: Pan de pancho solo") ||
                     dialogo.equals("CLIENTE 5: Yo quiero pan de bondiola con chimi y\n salchicha digo...rewfewrf") ||
                     dialogo.equals("CLIENTE 6: Superaste el dia Horacio, pero en verdad \n¿fue un dia comun y corriente?") || 
                     dialogo.equals("CLIENTE 6: Superaste el dia Horacio, pero en verdad \n¿fue un dia comun y corriente?") ;
    }

    private void verificarPausaSegunPedido() {
        switch(pedidoActual) {
        //DIALOGO CON PAUSA
            case 1: enPausa = (dialogoActual == 2); break;
            case 2: enPausa = (dialogoActual == 4); break;
            case 3: enPausa = (dialogoActual == 6); break;
            case 4: enPausa = (dialogoActual == 8); break;
            case 5: enPausa = (dialogoActual == 10); break;
            case 6: enPausa = (dialogoActual == 23); break;
            case 7: enPausa = (dialogoActual == 27); break;
            case 8: enPausa = (dialogoActual == 31); break;
            case 9: enPausa = (dialogoActual == 35); break;
        }
    }

    // Métodos de control de estado
    public String obtenerDialogoPedido(boolean pedidoCorrecto) {
        if (pedidoCorrecto) {
            return obtenerDialogoExitoso();
        } else {
            return obtenerDialogoFallido();
        }
    }

    private String obtenerDialogoExitoso() {
        switch(pedidoActual) {
            case 1: return "HORACIO: Aquí tienes tu pancho con ketchup, como me pediste.";
            case 2: return "HORACIO: Tuyo.";
            case 3: return "HORACIO: Acá tenes.";
            case 4: return "HORACIO: Aquí ta.";
            case 5: return "HORACIO: Sin problemas.";
            case 6: return "HORACIO: Todo en orden.";           
            default: return "";
        }
    }

    private String obtenerDialogoFallido() {
        switch(pedidoActual) {
            case 1: return "CLIENTA: ¡ME QUERES MATAR!";
            case 2: return "HORACIO: (Em... creo que no es lo que me pidió, ¿qué había pedido realmente?)";
            case 3: return "HORACIO: (¿no?)";
            case 4: return "CLIENTE: Esto no es lo que pedí.";
            case 5: return "CLIENTE: ¿Qué pasó?";
            case 6: return "CLIENTE: ¡Esto no está bien!";            
            default: return "";
        }
    }

    // Getters y setters
    public boolean debeAnimar() {
        return debeAnimar;
    }

    public void resetearAnimacion() {
        debeAnimar = false;
    }

    public int getPedidoActual() {
        return pedidoActual;
    }

    public void avanzarPedido() {
        pedidoActual++;
    }

    public boolean hayMasDialogos() {
        return dialogoActual < dialogos.length - 1;
    }

    public boolean estaEnPausa() {
        return enPausa;
    }

    public void setPausa(boolean pausa) {
        this.enPausa = pausa;
    }

    public int getIndiceDialogoActual() {
        return dialogoActual;
    }

    public void setIndiceDialogoActual(int indice) {
        if (indice >= 0 && indice < dialogos.length) {
            this.dialogoActual = indice;
        }
    }

    public int getCantidadDialogos() {
        return dialogos.length;
    }

    public boolean esUltimoDialogo() {
        return dialogoActual == dialogos.length - 1;
    }

    public String getDialogo(int indice) {
        if (indice >= 0 && indice < dialogos.length) {
            return dialogos[indice];
        }
        return "";
    }

    // Métodos de control de flujo
    public void reanudarDialogos(boolean pedidoCorrecto) {
        if (pedidoCorrecto) {
            enPausa = false;
        }
    }

    public void reiniciarDialogos() {
        dialogoActual = 0;
        pedidoActual = 1;
        debeAnimar = false;
        enPausa = false;
    }

    public boolean dialogoAnterior() {
        if (dialogoActual > 0) {
            dialogoActual--;
            return true;
        }
        return false;
    }
}