public class DialogManager {
    private String[] dialogos;
    private int dialogoActual;
    private boolean enPausa = false;
    // Agregar una variable para controlar si es momento de la animación de salida
    private boolean debeAnimar = false;

    public DialogManager() {
        // Agregar los diálogos básicos
        dialogos = new String[]{
        		"HORACIO: Ah, mi primer cliente.",
        		"*Horacio se prepara para atender a la joven que se aproxima.*",
        		"HORACIO: Hola, Que se le ofrece.?",
        		"CLIENTA: Hola, Me da un pancho con ketchup?",
        		"CLIENTA: Para preparar el pedido, elije los ingredientes del carrito.",
        		"HORACIO: Un pancho con ketchup? Ahora mismo.",

        		"CLIENTA: Gracias.",
        		"CLIENTA: *Come*.",
        		"HORACIO: (Que raro que no se este yendo).",
        		"HORACIO: Y, Sos de por aca?",
        		"CLIENTA: Si, vivo aca desde que soy chica.",
        		"HORACIO: Que raro nunca haberte visto, \nvivo aca hace mas de 60 a�os.",
        		"CLIENTA: Rarisimo, �No? en fin, mi nombre es Victoria, ¿Cual es el tuyo?",
        		"HORACIO: Horacio",
        		"HORACIO: (Todo esto me parece muy raro che).",
        		"VICTORIA: Bueno, ya me tengo que ir, dentro de poco son las fiestas.",
        		"HORACIO: (Fiestas?), Ok.... Suerte.",


        };
        dialogoActual = 0;
    }

    public String getDialogoActual() {
        if (dialogoActual < dialogos.length) {
            return dialogos[dialogoActual];
        }
        return "";
    }

    public boolean siguienteDialogo() {
        // No avanza si está en pausa
        if (enPausa) {
            return false;
        }
        if (dialogoActual < dialogos.length - 1) {
            dialogoActual++;
            // Activar pausa si llegamos al diálogo número 5
            if (dialogoActual == 5) {
                enPausa = true;
            }
            // Activar la animación cuando llegamos al diálogo "Gracias muy amable"
            if (dialogos[dialogoActual].equals("CLIENTA: *Come*")) {
                debeAnimar = true;
            }
            return true;
        }
        return false;
    }

    // Agregar método para verificar si debe animar
    public boolean debeAnimar() {
        return debeAnimar;
    }

    // Agregar método para resetear la animación
    public void resetearAnimacion() {
        debeAnimar = false;
    }

    // ... (mantener el resto de los métodos igual)

    public void reanudarDialogos(boolean pedidoCorrecto) {
        if (pedidoCorrecto) {
            enPausa = false;
        }
    }

    public boolean hayMasDialogos() {
        return dialogoActual < dialogos.length - 1;
    }

    public void reiniciarDialogos() {
        dialogoActual = 0;
        debeAnimar = false;
    }

    public String obtenerDialogoPedido(boolean pedidoCorrecto) {
        if (pedidoCorrecto) {
            return "HORACIO: Aqui tienes.";
        } else {
            return "HORACIO: Esto no es lo que me pidio.";
        }
    }
}