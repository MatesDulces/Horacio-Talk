public class DialogManager3 {
    private String[] dialogos;
    private int dialogoActual;
    private boolean debeAnimar = false;
    private boolean enPausa = false;
    private int pedidoActual = 1;

    public DialogManager3() {
        dialogos = new String[]{
        		"*Horacio no pudo reponer el stock de panchos, \nasi que esta vez compro bondiolas*",
        		"CLIENTE 1: YO, MY NAME IS SILLY BILLY AND I",
        		"HORACIO: ...",
        		"SILLY BILLY: YO I WANT AN UNMATCHED SANDWICH\nOF MEAT WITH CREOLE SAUCE",
        		"HORACIO: ??? ¿Y eso que es?",
        		"HORACIO: Tendre que investigar que es eso...",
        		
        		"SILLY BILLY: ¡GRACIAS HERMANO HASTA LUEGO!",
        		"HORACIO: Siguient--- ¿¿ES QUIEN YO CREO QUE ES??.",
        		"MARGE SIMPSON: Hola.",
        		"HORACIO: MARGE SIMPSON QUE HACES ACA.",
        		"MARGE SIMPSON: Vine a comprar una bondiola\n con mayo y ketchup para mi esposo Homero.",
        		"HORACIO: Como no mujer, ya mismo le preparo \nla bondiola.",

        		"MARGE SIMPSON: Seguro que le va a encantar,\n ¡Gracias!.",
        		"HORACIO: Dios, que encuentro inesperado, \nme alegro el dia",
        		"HORACIO: Siguiente porfav- OTRA VEZ NO.",
        		"SILLY BILLY: YO YO YO HERMANO QUIERO \nOTRA BONDIOLA PORFAVOR.",
        		"HORACIO: *Suspira* ¿Si te traigo la bondiola \nprometes no volver nunca mas?",
        		"SILLY BILLY: LO JURO COMO SI MI NOMBRE \nNO FUERA EL TONTO BILLY.",
        		
        		"HORACIO: (Esa frase ni siquiera tiene sentido….)",
        		"HORACIO: Ya por suerte es hora de terminar el dia.",

            
        };
        dialogoActual = 0;
    }


    // Obtiene el diálogo actual
    public String getDialogoActual() {
        if (dialogoActual < dialogos.length) {
            return dialogos[dialogoActual];
        }
        return "";
    }

    // Avanza al siguiente diálogo
    public boolean siguienteDialogo() {
        if (enPausa) {
            return false;
        }
        if (dialogoActual < dialogos.length - 1) {
            dialogoActual++;
            // Activa la pausa según el pedido actual
            if (pedidoActual == 1 && dialogoActual == 5) {
                enPausa = true;
            } else if (pedidoActual == 2 && dialogoActual == 11) {
                enPausa = true;
            } else if (pedidoActual == 3 && dialogoActual == 17) { // Nueva pausa para el tercer pedido
                enPausa = true;
            }
            // Activa la animación en momentos específicos
            if (dialogos[dialogoActual].equals("CLIENTA: Gracias maestro") ||
                dialogos[dialogoActual].equals("CLIENTE  Emm me llamo Hernan")) {
                debeAnimar = true;
            }
            return true;
        }
        return false;
    }

    // Verifica si debe animar
    public boolean debeAnimar() {
        return debeAnimar;
    }

    // Resetea la animación
    public void resetearAnimacion() {
        debeAnimar = false;
    }

    // Obtiene el pedido actual
    public int getPedidoActual() {
        return pedidoActual;
    }

    // Avanza al siguiente pedido
    public void avanzarPedido() {
        pedidoActual++;
    }

    // Reanuda los diálogos si el pedido es correcto
    public void reanudarDialogos(boolean pedidoCorrecto) {
        if (pedidoCorrecto) {
            enPausa = false;
        }
    }

    // Verifica si hay más diálogos
    public boolean hayMasDialogos() {
        return dialogoActual < dialogos.length - 1;
    }

    // Reinicia todos los diálogos
    public void reiniciarDialogos() {
        dialogoActual = 0;
        pedidoActual = 1;
        debeAnimar = false;
        enPausa = false;
    }

    // Obtiene el diálogo correspondiente según el estado del pedido
    public String obtenerDialogoPedido(boolean pedidoCorrecto) {
        switch(pedidoActual) {
            case 1:
                if (pedidoCorrecto) {
                    return "HORACIO: Aca tenes tu pedido Silly Billy.";
                } else {
                    return "SILLY BILLY: ESO NO ES LO QUE PEID HERMANO HAZLO BIEN";
                }
            case 2:
                if (pedidoCorrecto) {
                    return "HORACIO: Tu sanguche querida que tengas hermoso dia.";
                } else {
                    return "HORACIO: (Em.. Creo que no es lo que me pidio, ¿¿¿que habia pedido???) ";
                }
            case 3:
                if (pedidoCorrecto) {
                    return "HORACIO: THANKS VIEJO.";
                } else {
                    return "HORACIO: ... ¿no?";
                }
            default:
                return "";
        }
    }

    // Verifica si el diálogo está en pausa
    public boolean estaEnPausa() {
        return enPausa;
    }

    // Establece el estado de pausa
    public void setPausa(boolean pausa) {
        this.enPausa = pausa;
    }

    // Obtiene el índice del diálogo actual
    public int getIndiceDialogoActual() {
        return dialogoActual;
    }

    // Establece el índice del diálogo actual
    public void setIndiceDialogoActual(int indice) {
        if (indice >= 0 && indice < dialogos.length) {
            this.dialogoActual = indice;
        }
    }

    // Obtiene la cantidad total de diálogos
    public int getCantidadDialogos() {
        return dialogos.length;
    }

    // Verifica si es el último diálogo
    public boolean esUltimoDialogo() {
        return dialogoActual == dialogos.length - 1;
    }

    // Obtiene el diálogo por índice
    public String getDialogo(int indice) {
        if (indice >= 0 && indice < dialogos.length) {
            return dialogos[indice];
        }
        return "";
    }

    // Retrocede al diálogo anterior
    public boolean dialogoAnterior() {
        if (dialogoActual > 0) {
            dialogoActual--;
            return true;
        }
        return false;
    }
}