import java.awt.Graphics;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Color;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ImagenH extends JFrame {
    private static final long serialVersionUID = 1L;
    
    public ImagenH() {
        // Configurar el frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setUndecorated(true); // Elimina la decoración de la ventana
    }
    
    @Override
    public void setVisible(boolean b) {
        // Cargar la imagen de fondo
        ImageIcon backgroundImage = new ImageIcon(Home.class.getResource("/ingredientes/HoracioDespertar.png"));
        
        // Crear el panel donde se dibujará la imagen
        JPanel contentPane = new JPanel() {
            private static final long serialVersionUID = 1L;
            
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                
                // Dibujar la imagen de fondo ajustada al tamaño del panel
                if (backgroundImage != null) {
                    g.drawImage(backgroundImage.getImage(), 0, 0, getWidth(), getHeight(), this);
                }
            }
        };
        
        // Configuración del contenedor
        contentPane.setLayout(null);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        
        // Crear botón de salida
        JButton exitButton = new JButton("Salir");
        exitButton.setFont(new Font("Arial", Font.BOLD, 14));
        exitButton.setBackground(Color.RED);
        exitButton.setForeground(Color.WHITE);
        
        // Posicionar el botón en la esquina superior derecha
        exitButton.setBounds(getWidth() - 100, 10, 90, 30);
        
        // Añadir acción al botón
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	Home home = new Home();
                dispose();
                home.setVisible(true); // Cierra la aplicación
            }
        });
        
        // Añadir el botón al panel
        contentPane.add(exitButton);
        
        // Configurar pantalla completa
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        GraphicsDevice gd = ge.getDefaultScreenDevice();
        
        if (gd.isFullScreenSupported()) {
            gd.setFullScreenWindow(this);
        } else {
            // Si no se soporta el modo pantalla completa, maximizar la ventana
            setExtendedState(JFrame.MAXIMIZED_BOTH);
        }
        
        super.setVisible(b);
    }
    
    // Método main para probar la clase
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            new ImagenH().setVisible(true);
        });
    }
}