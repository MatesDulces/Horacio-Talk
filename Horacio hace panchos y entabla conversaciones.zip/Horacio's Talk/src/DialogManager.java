public class DialogManager {
    private String[] dialogos;
    private int dialogoActual;
    private boolean enPausa = false;

    
    public DialogManager() {
        // Agregar los di�logos b�sicos
        dialogos = new String[]{
            "HORACIO: Ah, mi primer cliente",
            "*Horacio se prepara para atender a la joven que llega*",
            "CLIENTA: Hola buen d�a, �te puedo pedir un pancho con ketchup?",
            "CLIENTA: Para preparar el pedido, selecciona los ingredientes en orden \ndesde el men� izquierdo.",
            "HORACIO: Como no, ya va",
            // Los di�logos relacionados con el pedido solo ser�n actualizados al presionar el bot�n
            
            "CLIENTA: Gracias muy amable",
            "HORACIO: chupame el pingo",
            "CLIENTA: �Tienes alguna oferta para mi pr�ximo pedido?",
            "HORACIO: Claro, chupame el pingo."
        };
        dialogoActual = 0;
    }
    
    public String getDialogoActual() {
        if (dialogoActual < dialogos.length) {
            return dialogos[dialogoActual];
        }
        return "";
    }
    
    public boolean siguienteDialogo() {
        // No avanza si est� en pausa
        if (enPausa) {
            return false;
        }
        if (dialogoActual < dialogos.length - 1) {
            dialogoActual++;
            // Activar pausa si llegamos al di�logo n�mero 5
            if (dialogoActual == 4) { // Asumiendo que el di�logo 5 es el n�mero de di�logo en el que quieres pausar
                enPausa = true; // Activa la pausa
            }
            return true;
        }
        return false;
    }
    
    public void reanudarDialogos(boolean pedidoCorrecto) {
        if (pedidoCorrecto) {
            enPausa = false; // Desactiva la pausa solo si el pedido es correcto
        }
    }

    
    public boolean hayMasDialogos() {
        return dialogoActual < dialogos.length - 1;
    }
    
    public void reiniciarDialogos() {
        dialogoActual = 0;  // Reiniciar al principio de los di�logos
    }

    
    // M�todo que solo se usa cuando se presiona el bot�n de entregar el pedido
    public String obtenerDialogoPedido(boolean pedidoCorrecto) {
        if (pedidoCorrecto) {
            return "HORACIO: �El pedido est� listo! Aqu� tienes tu pancho con ketchup.";
        } else {
            return "HORACIO: �El pedido no es correcto! Aseg�rate de agregar\nlos ingredientes correctos.";
        }
    }
}
