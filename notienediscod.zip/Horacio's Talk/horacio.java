
public class Episodio1 {

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}

}
