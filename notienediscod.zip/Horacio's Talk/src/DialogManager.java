public class DialogManager {
    private String[] dialogos;
    private int dialogoActual;
    private boolean enPausa = false;
    // Agregar una variable para controlar si es momento de la animación de salida
    private boolean debeAnimar = false;

    public DialogManager() {
        // Agregar los diálogos básicos
        dialogos = new String[]{
        		 "HORACIO: Ah, mi primer cliente",
                 "*Horacio se prepara para atender a la joven que llega*",
                 "CLIENTA: Hola buen d�a, �te puedo pedir un pancho con ketchup?",
                 "CLIENTA: Para preparar el pedido, selecciona los ingredientes en orden \ndesde el men� izquierdo.",
                 "HORACIO: Como no, ya va",
                 "CLIENTA: *Come*",
                 "HORACIO: ...",
                 "HORACIO: �Y.... �Cual es tu nombre?\nnunca te habia visto por aca",
                 "CLIENTA: Victoria.",
                 "HORACIO: Un gusto.",
                 "VICTORIA: Igualmente, �Y vos sos de por aca?",
                 "HORACIO: Si, vivo ac� desde que soy chico,",
                 "HORACIO: pero la falta de plata, las nuevas pol�ticas y\n una mala gesti�n fundieron mi anterior negocio...",
                 "HORACIO: Y no me quedo de otra que empezar de nuevo como pude.",
                 "HORACIO: Perdon, me fui mucho de tema.",
                 "VICTORIA: Tranqui, no hay problema, es una mierda.",
                 "VICTORIA Y HORACIO: �",
                 "HORACIO: �Y vos sos de por aca?",
                 "VICTORIA: Si, soy de un par de cuadras bajando pero no suelo venir mucho por \n esta zona,",
                 "VICTORIA: Vine a visitar a una compa�era de telas.",
                 "HORACIO: �Telas? �Es un tipo de deporte eso?",
                 "VICTORIA: Si, es un tipo de deporte de engancharse en el aire \n utilizando telas",
                 "VICTORIA: Es un poco complicado de explicar asi al aire.",
                 "HORACIO: Entiendo, se ve interesante.",
                 "HORACIO: Bueno, no te hago perder m�s tiempo con mi vida, \nsuerte.",
                 "VICTORIA: Igualmente, suerte estuvo muy bueno el pancho, gracias",
                 "VICTORIA: Espero que te vaya bien.",
				 "HORACIO: (Ojal�).",
				 "HORACIO: (Ojal� que vuelva tambi�n, es una persona agradable).",

        };
        dialogoActual = 0;
    }

    public String getDialogoActual() {
        if (dialogoActual < dialogos.length) {
            return dialogos[dialogoActual];
        }
        return "";
    }

    public boolean siguienteDialogo() {
        // No avanza si está en pausa
        if (enPausa) {
            return false;
        }
        if (dialogoActual < dialogos.length - 1) {
            dialogoActual++;
            // Activar pausa si llegamos al diálogo número 5
            if (dialogoActual == 4) {
                enPausa = true;
            }
            // Activar la animación cuando llegamos al diálogo "Gracias muy amable"
            if (dialogos[dialogoActual].equals("CLIENTA: Gracias muy amable")) {
                debeAnimar = true;
            }
            return true;
        }
        return false;
    }

    // Agregar método para verificar si debe animar
    public boolean debeAnimar() {
        return debeAnimar;
    }

    // Agregar método para resetear la animación
    public void resetearAnimacion() {
        debeAnimar = false;
    }

    // ... (mantener el resto de los métodos igual)

    public void reanudarDialogos(boolean pedidoCorrecto) {
        if (pedidoCorrecto) {
            enPausa = false;
        }
    }

    public boolean hayMasDialogos() {
        return dialogoActual < dialogos.length - 1;
    }

    public void reiniciarDialogos() {
        dialogoActual = 0;
        debeAnimar = false;
    }

    public String obtenerDialogoPedido(boolean pedidoCorrecto) {
        if (pedidoCorrecto) {
            return "HORACIO: �El pedido esta� listo! Aqui tienes tu pancho con ketchup.";
        } else {
            return "HORACIO: �El pedido no es correcto! Asegurate de agregar\nlos ingredientes correctos.";
        }
    }
}